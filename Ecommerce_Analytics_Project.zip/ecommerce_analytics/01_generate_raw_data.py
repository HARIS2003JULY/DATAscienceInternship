"""
STEP 1 - Generate a realistic, MESSY raw e-commerce dataset.

If you have your own dataset (e.g. from Kaggle), skip this script and put your
file at data/raw_ecommerce_orders.csv, then adapt 02_data_cleaning.py column names.

The raw file intentionally contains: missing values, duplicates, outliers,
wrong data types, inconsistent text casing/spelling and mixed date formats,
so that the cleaning step (Part 1 of the task) has real work to do.
"""
import numpy as np
import pandas as pd
from pathlib import Path

rng = np.random.default_rng(42)
OUT = Path(__file__).parent / "data"
OUT.mkdir(exist_ok=True)

N_ORDERS = 12000
N_CUSTOMERS = 2500

# ---------- Product catalogue ----------
catalog = {
    "Electronics": {"Smartphone": (350, 0.12), "Laptop": (800, 0.10), "Headphones": (80, 0.30),
                    "Smartwatch": (180, 0.22), "Tablet": (320, 0.14)},
    "Fashion": {"T-Shirt": (22, 0.45), "Jeans": (55, 0.40), "Sneakers": (85, 0.35),
                "Jacket": (120, 0.38), "Handbag": (95, 0.42)},
    "Home & Kitchen": {"Blender": (60, 0.30), "Cookware Set": (110, 0.28), "Vacuum Cleaner": (150, 0.20),
                       "Bedding Set": (70, 0.35), "Coffee Maker": (90, 0.25)},
    "Beauty": {"Moisturizer": (28, 0.55), "Perfume": (65, 0.50), "Makeup Kit": (48, 0.52),
               "Hair Dryer": (45, 0.30)},
    "Sports": {"Yoga Mat": (25, 0.40), "Dumbbell Set": (75, 0.28), "Running Shoes": (90, 0.30),
               "Fitness Tracker": (60, 0.25)},
    "Books & Stationery": {"Novel": (14, 0.35), "Textbook": (60, 0.15), "Notebook Pack": (9, 0.45),
                           "Pen Set": (12, 0.40)},
}
products = []
for cat, items in catalog.items():
    for name, (price, margin) in items.items():
        products.append((cat, name, price, margin))
prod_df = pd.DataFrame(products, columns=["category", "product", "base_price", "margin"])
# popularity weights (some products sell much more)
pop = rng.dirichlet(np.ones(len(prod_df)) * 1.2)

# ---------- Customers ----------
regions = {
    "North America": ["New York", "Los Angeles", "Chicago", "Toronto", "Houston"],
    "Europe": ["London", "Berlin", "Paris", "Madrid", "Amsterdam"],
    "Asia": ["Karachi", "Lahore", "Dubai", "Mumbai", "Singapore"],
    "Australia": ["Sydney", "Melbourne", "Brisbane"],
    "South America": ["Sao Paulo", "Buenos Aires", "Bogota"],
}
region_w = {"North America": 0.32, "Europe": 0.28, "Asia": 0.25, "Australia": 0.08, "South America": 0.07}
cust_ids = [f"C{str(i).zfill(5)}" for i in range(1, N_CUSTOMERS + 1)]
cust_region = rng.choice(list(region_w), size=N_CUSTOMERS, p=list(region_w.values()))
cust_city = [rng.choice(regions[r]) for r in cust_region]
cust_segment = rng.choice(["Consumer", "Corporate", "Home Office"], size=N_CUSTOMERS, p=[0.55, 0.28, 0.17])
cust_age = np.clip(rng.normal(36, 11, N_CUSTOMERS).round(), 18, 75).astype(int)
cust_gender = rng.choice(["Male", "Female"], size=N_CUSTOMERS, p=[0.48, 0.52])
# customer activity weight - heavy-tailed so some are loyal
cust_w = rng.pareto(2.2, N_CUSTOMERS) + 0.2
cust_w /= cust_w.sum()
# churn behaviour: a share of customers stops buying after some date
churner = rng.random(N_CUSTOMERS) < 0.30
churn_after = pd.to_datetime("2023-01-01") + pd.to_timedelta(rng.integers(120, 700, N_CUSTOMERS), unit="D")

# ---------- Orders ----------
start, end = pd.Timestamp("2023-01-01"), pd.Timestamp("2024-12-31")
days = (end - start).days + 1
day_idx = np.arange(days)
dates_all = start + pd.to_timedelta(day_idx, unit="D")
month_season = {1: .85, 2: .8, 3: .9, 4: .95, 5: 1.0, 6: .95, 7: .9, 8: .95, 9: 1.0, 10: 1.1, 11: 1.6, 12: 1.45}
growth = 1 + 0.45 * day_idx / days  # business grows ~45% over two years
dow = np.array([1.0, .95, .95, 1.0, 1.1, 1.2, 1.15])
w = np.array([month_season[d.month] * dow[d.dayofweek] for d in dates_all]) * growth
w /= w.sum()

order_dates = rng.choice(dates_all, size=N_ORDERS, p=w)
cust_idx = rng.choice(N_CUSTOMERS, size=N_ORDERS, p=cust_w)
# enforce churn
for k in range(N_ORDERS):
    c = cust_idx[k]
    if churner[c] and order_dates[k] > np.datetime64(churn_after[c]):
        order_dates[k] = np.datetime64(start + pd.Timedelta(days=int(rng.integers(0, (churn_after[c] - start).days))))

prod_idx = rng.choice(len(prod_df), size=N_ORDERS, p=pop)
qty = rng.choice([1, 2, 3, 4, 5], size=N_ORDERS, p=[0.55, 0.25, 0.1, 0.06, 0.04])
discount = rng.choice([0, 0.05, 0.10, 0.15, 0.20, 0.30], size=N_ORDERS, p=[0.45, 0.15, 0.15, 0.12, 0.08, 0.05])
ship_mode = rng.choice(["Standard", "Express", "Same Day", "Free Shipping"], size=N_ORDERS, p=[.5, .25, .08, .17])
pay = rng.choice(["Credit Card", "Debit Card", "PayPal", "Cash on Delivery", "Bank Transfer"], size=N_ORDERS,
                 p=[.35, .22, .2, .15, .08])
channel = rng.choice(["Organic Search", "Paid Ads", "Email", "Social Media", "Direct", "Referral"], size=N_ORDERS,
                     p=[.26, .22, .14, .18, .14, .06])
rating = rng.choice([1, 2, 3, 4, 5], size=N_ORDERS, p=[.05, .07, .15, .35, .38]).astype(float)

p = prod_df.iloc[prod_idx].reset_index(drop=True)
unit_price = (p["base_price"] * rng.normal(1, 0.06, N_ORDERS)).round(2)
sales = (unit_price * qty * (1 - discount)).round(2)
# profit: margin on list price, hurt by discount, shipping costs
ship_cost = pd.Series(ship_mode).map({"Standard": 4, "Express": 9, "Same Day": 15, "Free Shipping": 6}).values
cogs = unit_price * qty * (1 - p["margin"].values)
profit = (sales - cogs - ship_cost).round(2)

df = pd.DataFrame({
    "Order ID": [f"ORD-{100000 + i}" for i in range(N_ORDERS)],
    "Order Date": pd.to_datetime(order_dates),
    "Customer ID": np.array(cust_ids)[cust_idx],
    "Customer Age": cust_age[cust_idx],
    "Gender": cust_gender[cust_idx],
    "Segment": cust_segment[cust_idx],
    "Region": cust_region[cust_idx],
    "City": np.array(cust_city)[cust_idx],
    "Category": p["category"],
    "Product": p["product"],
    "Unit Price": unit_price,
    "Quantity": qty,
    "Discount": discount,
    "Sales": sales,
    "Profit": profit,
    "Shipping Mode": ship_mode,
    "Payment Method": pay,
    "Marketing Channel": channel,
    "Rating": rating,
})
df["Ship Date"] = df["Order Date"] + pd.to_timedelta(
    np.where(df["Shipping Mode"] == "Same Day", 0,
             np.where(df["Shipping Mode"] == "Express", rng.integers(1, 3, N_ORDERS), rng.integers(3, 8, N_ORDERS))),
    unit="D")

# ---------- Inject mess ----------
raw = df.copy()
# 1. mixed date formats stored as text
fmt = rng.choice(["%Y-%m-%d", "%d/%m/%Y", "%m-%d-%Y", "%b %d, %Y"], size=N_ORDERS, p=[.55, .2, .15, .1])
raw["Order Date"] = [d.strftime(f) for d, f in zip(raw["Order Date"], fmt)]
raw["Ship Date"] = [d.strftime("%Y-%m-%d") for d in raw["Ship Date"]]
# 2. inconsistent text
for col in ["Region", "Category", "Shipping Mode", "Segment"]:
    mask = rng.random(N_ORDERS) < 0.06
    raw.loc[mask, col] = raw.loc[mask, col].str.upper()
    mask = rng.random(N_ORDERS) < 0.04
    raw.loc[mask, col] = " " + raw.loc[mask, col].astype(str) + "  "
mask = rng.random(N_ORDERS) < 0.03
raw.loc[mask, "Region"] = raw.loc[mask, "Region"].replace({"North America": "N. America", "Europe": "Europ"})
# 3. currency symbols / strings in numeric columns
mask = rng.random(N_ORDERS) < 0.04
raw["Sales"] = raw["Sales"].astype(object)
raw.loc[mask, "Sales"] = "$" + raw.loc[mask, "Sales"].astype(str)
raw["Discount"] = raw["Discount"].astype(object)
mask = rng.random(N_ORDERS) < 0.05
raw.loc[mask, "Discount"] = (raw.loc[mask, "Discount"].astype(float) * 100).astype(int).astype(str) + "%"
# 4. missing values
for col, rate in {"Customer Age": .05, "Gender": .03, "City": .02, "Rating": .12, "Payment Method": .015,
                  "Profit": .01, "Marketing Channel": .03, "Segment": .01}.items():
    raw.loc[rng.random(N_ORDERS) < rate, col] = np.nan
# 5. outliers
idx = rng.choice(N_ORDERS, 25, replace=False)
raw.loc[idx, "Quantity"] = rng.choice([50, 99, 150, -3], size=25)
idx = rng.choice(N_ORDERS, 15, replace=False)
raw.loc[idx, "Customer Age"] = rng.choice([0, 5, 120, 999], size=15)
idx = rng.choice(N_ORDERS, 20, replace=False)
raw.loc[idx, "Unit Price"] = raw.loc[idx, "Unit Price"] * rng.choice([10, 25], size=20)
# 6. duplicates (exact + near)
dups = raw.sample(220, random_state=1)
raw = pd.concat([raw, dups], ignore_index=True).sample(frac=1, random_state=7).reset_index(drop=True)

raw.to_csv(OUT / "raw_ecommerce_orders.csv", index=False)
print(f"Raw dataset saved: {OUT/'raw_ecommerce_orders.csv'}  shape={raw.shape}")
