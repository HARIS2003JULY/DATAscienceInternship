"""
STEP 2 - PART 1: DATA PREPARATION
Import raw data -> clean -> engineer features -> save clean dataset.
Produces: data/clean_orders.csv, outputs/cleaning_report.txt
"""
import numpy as np
import pandas as pd
from pathlib import Path

BASE = Path(__file__).parent
raw = pd.read_csv(BASE / "data" / "raw_ecommerce_orders.csv")
log = []


def note(msg):
    print(msg)
    log.append(msg)


note("=" * 60)
note("DATA CLEANING REPORT")
note("=" * 60)
note(f"1. Imported raw data: {raw.shape[0]:,} rows x {raw.shape[1]} columns")
note("\n-- Missing values BEFORE cleaning --")
note(raw.isna().sum()[raw.isna().sum() > 0].to_string())

df = raw.copy()

# ---------- 2. Duplicate removal ----------
n0 = len(df)
df = df.drop_duplicates().drop_duplicates(subset="Order ID", keep="first")
note(f"\n2. Duplicate removal: removed {n0 - len(df):,} duplicate rows")

# ---------- 3. Text standardisation ----------
for col in ["Region", "Category", "Shipping Mode", "Segment", "Gender", "City", "Payment Method", "Marketing Channel"]:
    df[col] = df[col].astype("string").str.strip()
df["Region"] = df["Region"].str.title().replace({"N. America": "North America", "Europ": "Europe"})
for col in ["Category", "Shipping Mode", "Segment"]:
    df[col] = df[col].str.title() if col != "Category" else df[col]
cat_fix = {c.upper(): c for c in ["Electronics", "Fashion", "Home & Kitchen", "Beauty", "Sports", "Books & Stationery"]}
df["Category"] = df["Category"].map(lambda x: cat_fix.get(x.upper(), x) if pd.notna(x) else x)
note("3. Text columns trimmed and standardised (case, spelling, whitespace)")

# ---------- 4. Data type correction ----------
def parse_date(s):
    for f in ("%Y-%m-%d", "%d/%m/%Y", "%m-%d-%Y", "%b %d, %Y"):
        try:
            return pd.to_datetime(s, format=f)
        except (ValueError, TypeError):
            continue
    return pd.NaT


df["Order Date"] = df["Order Date"].map(parse_date)
df["Ship Date"] = pd.to_datetime(df["Ship Date"], errors="coerce")
df["Sales"] = pd.to_numeric(df["Sales"].astype(str).str.replace("$", "", regex=False), errors="coerce")
disc = df["Discount"].astype(str)
df["Discount"] = np.where(disc.str.endswith("%"), pd.to_numeric(disc.str.rstrip("%"), errors="coerce") / 100,
                          pd.to_numeric(disc, errors="coerce"))
df["Quantity"] = pd.to_numeric(df["Quantity"], errors="coerce")
note("4. Data types fixed: dates parsed from 4 mixed formats, '$'/'%' symbols stripped from numbers")
bad_dates = df["Order Date"].isna().sum()
df = df.dropna(subset=["Order Date"])
note(f"   Rows dropped for unparseable order date: {bad_dates}")

# ---------- 5. Outlier analysis & treatment ----------
note("\n5. Outlier analysis")
# Unit price: > 3x product median -> replace by product median
med_price = df.groupby("Product")["Unit Price"].transform("median")
bad_price = df["Unit Price"] > 3 * med_price
note(f"   Unit Price outliers (>3x product median): {bad_price.sum()} -> replaced with product median")
df.loc[bad_price, "Unit Price"] = med_price[bad_price]
# Quantity: valid range 1..10; infer from Sales when possible
bad_qty = (df["Quantity"] < 1) | (df["Quantity"] > 10)
inferred = (df["Sales"] / (df["Unit Price"] * (1 - df["Discount"]).clip(lower=0.01))).round().clip(1, 5)
note(f"   Quantity outliers (<1 or >10): {bad_qty.sum()} -> re-derived from Sales / (price x (1-discount))")
df.loc[bad_qty, "Quantity"] = inferred[bad_qty]
# Age: valid 18..80, otherwise NaN (imputed below)
bad_age = (df["Customer Age"] < 18) | (df["Customer Age"] > 80)
note(f"   Customer Age outliers (<18 or >80): {bad_age.sum()} -> set to missing, then imputed")
df.loc[bad_age, "Customer Age"] = np.nan
# IQR check on Sales (reported, retained: high-value orders are genuine)
q1, q3 = df["Sales"].quantile([.25, .75])
iqr = q3 - q1
n_out = ((df["Sales"] > q3 + 1.5 * iqr)).sum()
note(f"   Sales IQR outliers: {n_out} high-value orders -> RETAINED (genuine big-ticket purchases, e.g. laptops)")
# Cap extreme Sales at 99.9th percentile for modelling stability only in a separate column
df["Sales_capped"] = df["Sales"].clip(upper=df["Sales"].quantile(0.999))

# ---------- 6. Missing value treatment ----------
note("\n6. Missing value treatment")
# Customer attributes: fill from the same customer's other orders first
for col in ["Customer Age", "Gender", "Segment", "City", "Region"]:
    df[col] = df.groupby("Customer ID")[col].transform(lambda s: s.fillna(s.dropna().iloc[0]) if s.notna().any() else s)
df["Customer Age"] = df["Customer Age"].fillna(df["Customer Age"].median()).round().astype(int)
note("   Customer Age: filled from same customer's other orders, else median")
for col in ["Gender", "Segment", "City", "Payment Method", "Marketing Channel"]:
    mode = df[col].mode()[0]
    n = df[col].isna().sum()
    df[col] = df[col].fillna(mode)
    note(f"   {col}: {n} missing -> mode ('{mode}')")
n = df["Rating"].isna().sum()
df["Rating_Missing"] = df["Rating"].isna().astype(int)
df["Rating"] = df["Rating"].fillna(df.groupby("Product")["Rating"].transform("median")).fillna(df["Rating"].median())
note(f"   Rating: {n} missing -> product median (flag column Rating_Missing kept)")
# Profit: rebuild with category-level average margin on sales
n = df["Profit"].isna().sum()
cat_margin = (df.groupby("Category")["Profit"].sum() / df.groupby("Category")["Sales"].sum())
df["Profit"] = df["Profit"].fillna(df["Sales"] * df["Category"].map(cat_margin)).round(2)
note(f"   Profit: {n} missing -> Sales x category average profit margin")

# ---------- 7. Feature engineering ----------
df["Year"] = df["Order Date"].dt.year
df["Month"] = df["Order Date"].dt.month
df["Month Name"] = df["Order Date"].dt.strftime("%b")
df["Quarter"] = "Q" + df["Order Date"].dt.quarter.astype(str)
df["YearMonth"] = df["Order Date"].dt.to_period("M").astype(str)
df["Day of Week"] = df["Order Date"].dt.day_name()
df["Is Weekend"] = df["Order Date"].dt.dayofweek.isin([5, 6]).astype(int)
df["Shipping Days"] = (df["Ship Date"] - df["Order Date"]).dt.days
df["Profit Margin %"] = (df["Profit"] / df["Sales"] * 100).round(2)
df["Is Loss"] = (df["Profit"] < 0).astype(int)
df["Age Group"] = pd.cut(df["Customer Age"], [17, 24, 34, 44, 54, 80],
                         labels=["18-24", "25-34", "35-44", "45-54", "55+"]).astype(str)
df["Discount Band"] = pd.cut(df["Discount"], [-0.01, 0, 0.10, 0.20, 1],
                             labels=["No Discount", "1-10%", "11-20%", ">20%"]).astype(str)
df["Order Value Band"] = pd.cut(df["Sales"], [0, 50, 150, 400, 1e9],
                                labels=["Small (<$50)", "Medium ($50-150)", "Large ($150-400)", "Premium ($400+)"]).astype(str)
note("\n7. Feature engineering: Year, Month, Quarter, YearMonth, Day of Week, Is Weekend, Shipping Days,")
note("   Profit Margin %, Is Loss, Age Group, Discount Band, Order Value Band")

df = df.sort_values("Order Date").reset_index(drop=True)
assert df.isna().sum().sum() == 0, df.isna().sum()[df.isna().sum() > 0]
assert df["Order ID"].is_unique
note(f"\nFINAL clean dataset: {df.shape[0]:,} rows x {df.shape[1]} columns | missing values: 0 | duplicate orders: 0")

df.to_csv(BASE / "data" / "clean_orders.csv", index=False)
(BASE / "outputs").mkdir(exist_ok=True)
(BASE / "outputs" / "cleaning_report.txt").write_text("\n".join(log), encoding="utf-8")
print("Saved data/clean_orders.csv and outputs/cleaning_report.txt")
