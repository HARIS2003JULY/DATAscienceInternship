"""
STEP 3 - PART 2 (EDA) and PART 3 (KPIs)
Creates 18 static charts in charts/ and the KPI tables in outputs/.
"""
import warnings
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import seaborn as sns
from pathlib import Path

warnings.filterwarnings("ignore")
BASE = Path(__file__).parent
CH = BASE / "charts"
CH.mkdir(exist_ok=True)
OUT = BASE / "outputs"
OUT.mkdir(exist_ok=True)

df = pd.read_csv(BASE / "data" / "clean_orders.csv", parse_dates=["Order Date", "Ship Date"])
sns.set_theme(style="whitegrid", font_scale=1.0)
PAL = "viridis"
BLUE, ORANGE, RED, GREEN = "#2563eb", "#f59e0b", "#dc2626", "#16a34a"
chart_no = [0]


def save(title, fname):
    chart_no[0] += 1
    plt.title(f"{chart_no[0]}. {title}", fontsize=13, fontweight="bold", loc="left")
    plt.tight_layout()
    plt.savefig(CH / f"{chart_no[0]:02d}_{fname}.png", dpi=130)
    plt.close()


# =============================================================== PART 3: KPIs
total_rev = df["Sales"].sum()
total_profit = df["Profit"].sum()
orders = df["Order ID"].nunique()
cust = df["Customer ID"].nunique()
aov = total_rev / orders
margin = total_profit / total_rev * 100
yearly = df.groupby("Year").agg(Revenue=("Sales", "sum"), Profit=("Profit", "sum"), Orders=("Order ID", "nunique"),
                                Customers=("Customer ID", "nunique"))
yoy_rev = (yearly["Revenue"].iloc[-1] / yearly["Revenue"].iloc[0] - 1) * 100
yoy_profit = (yearly["Profit"].iloc[-1] / yearly["Profit"].iloc[0] - 1) * 100
monthly = df.groupby("YearMonth").agg(Revenue=("Sales", "sum"), Profit=("Profit", "sum"), Orders=("Order ID", "nunique"))
monthly["MoM Growth %"] = monthly["Revenue"].pct_change() * 100
cust_orders = df.groupby("Customer ID")["Order ID"].nunique()
repeat_rate = (cust_orders > 1).mean() * 100
rev_per_cust = total_rev / cust
last_date = df["Order Date"].max()
last_buy = df.groupby("Customer ID")["Order Date"].max()
churned = ((last_date - last_buy).dt.days > 180).mean() * 100

kpis = {
    "Total Revenue": f"${total_rev:,.0f}",
    "Total Profit": f"${total_profit:,.0f}",
    "Total Orders": f"{orders:,}",
    "Average Order Value": f"${aov:,.2f}",
    "Profit Margin": f"{margin:.2f}%",
    "Customer Count": f"{cust:,}",
    "Revenue Growth (2024 vs 2023)": f"{yoy_rev:.1f}%",
    "Profit Growth (2024 vs 2023)": f"{yoy_profit:.1f}%",
    "Revenue per Customer": f"${rev_per_cust:,.2f}",
    "Repeat Customer Rate": f"{repeat_rate:.1f}%",
    "Customers inactive > 180 days": f"{churned:.1f}%",
    "Average Rating": f"{df['Rating'].mean():.2f}",
    "Loss-making Orders": f"{df['Is Loss'].mean()*100:.1f}%",
}
pd.Series(kpis, name="Value").to_frame().to_csv(OUT / "kpi_summary.csv")
yearly.to_csv(OUT / "kpi_yearly.csv")
monthly.to_csv(OUT / "kpi_monthly.csv")
print("\nKPI SUMMARY\n" + "-" * 40)
for k, v in kpis.items():
    print(f"{k:35s} {v}")

# =============================================================== PART 2: EDA
# ---- TRENDS ----
m = monthly.reset_index()
plt.figure(figsize=(12, 5))
plt.plot(m["YearMonth"], m["Revenue"], marker="o", color=BLUE, label="Revenue")
plt.plot(m["YearMonth"], m["Profit"], marker="s", color=GREEN, label="Profit")
plt.xticks(rotation=70)
plt.ylabel("USD")
plt.legend()
save("Monthly Revenue & Profit Trend", "monthly_trend")

plt.figure(figsize=(12, 4.5))
colors = [GREEN if v >= 0 else RED for v in m["MoM Growth %"].fillna(0)]
plt.bar(m["YearMonth"], m["MoM Growth %"].fillna(0), color=colors)
plt.xticks(rotation=70)
plt.ylabel("MoM growth %")
save("Month-over-Month Revenue Growth", "mom_growth")

q = df.groupby(["Year", "Quarter"])["Sales"].sum().unstack()
q.plot(kind="bar", figsize=(8, 5), colormap=PAL)
plt.ylabel("Revenue (USD)")
plt.xticks(rotation=0)
save("Quarterly Revenue by Year", "quarterly")

plt.figure(figsize=(9, 5))
dow = df.groupby("Day of Week")["Sales"].sum().reindex(
    ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"])
sns.barplot(x=dow.index, y=dow.values, palette=PAL)
plt.xticks(rotation=30)
plt.ylabel("Revenue")
save("Revenue by Day of Week", "day_of_week")

# ---- TOP / POOR PERFORMERS ----
cat = df.groupby("Category").agg(Revenue=("Sales", "sum"), Profit=("Profit", "sum")).sort_values("Revenue")
cat["Margin %"] = cat["Profit"] / cat["Revenue"] * 100
cat.to_csv(OUT / "category_performance.csv")
cat[["Revenue", "Profit"]].plot(kind="barh", figsize=(10, 5), color=[BLUE, GREEN])
save("Revenue vs Profit by Category", "category_rev_profit")

plt.figure(figsize=(9, 5))
cm = cat.sort_values("Margin %")
sns.barplot(x=cm["Margin %"], y=cm.index, palette="RdYlGn")
plt.xlabel("Profit margin %")
save("Profit Margin % by Category", "category_margin")

prod = df.groupby(["Category", "Product"]).agg(Revenue=("Sales", "sum"), Profit=("Profit", "sum"),
                                                Units=("Quantity", "sum")).reset_index()
prod["Margin %"] = prod["Profit"] / prod["Revenue"] * 100
prod.to_csv(OUT / "product_performance.csv", index=False)
top10 = prod.nlargest(10, "Profit").sort_values("Profit")
plt.figure(figsize=(10, 5.5))
plt.barh(top10["Product"], top10["Profit"], color=GREEN)
plt.xlabel("Profit (USD)")
save("Top 10 Products by Profit", "top_products")

bot10 = prod.nsmallest(10, "Profit").sort_values("Profit", ascending=False)
plt.figure(figsize=(10, 5.5))
plt.barh(bot10["Product"], bot10["Profit"], color=RED)
plt.xlabel("Profit (USD)")
save("Bottom 10 Products by Profit", "bottom_products")

plt.figure(figsize=(10, 6))
sns.scatterplot(data=prod, x="Revenue", y="Margin %", hue="Category", size="Units", sizes=(40, 400), alpha=.8)
plt.axhline(prod["Margin %"].mean(), ls="--", color="grey")
plt.legend(bbox_to_anchor=(1.02, 1), loc="upper left", fontsize=8)
save("Product Matrix: Revenue vs Margin (bubble = units)", "product_matrix")

# ---- RELATIONSHIPS ----
plt.figure(figsize=(8, 5))
d = df.groupby("Discount Band").agg(Profit_Margin=("Profit Margin %", "mean"), Orders=("Order ID", "count")).reindex(
    ["No Discount", "1-10%", "11-20%", ">20%"])
sns.barplot(x=d.index, y=d["Profit_Margin"], palette="RdYlGn")
plt.ylabel("Average profit margin %")
save("Discount Level vs Profit Margin", "discount_margin")

num = df[["Sales", "Profit", "Quantity", "Discount", "Unit Price", "Customer Age", "Rating", "Shipping Days",
          "Profit Margin %"]]
plt.figure(figsize=(9, 7))
sns.heatmap(num.corr(), annot=True, fmt=".2f", cmap="coolwarm", center=0)
save("Correlation Heatmap", "correlation")

hm = df.pivot_table(index="Category", columns="Month Name", values="Sales", aggfunc="sum")
hm = hm[["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]]
plt.figure(figsize=(12, 5))
sns.heatmap(hm, cmap="YlGnBu", annot=False)
save("Seasonality Heatmap: Category x Month (Revenue)", "seasonality")

# ---- REGIONAL ----
reg = df.groupby("Region").agg(Revenue=("Sales", "sum"), Profit=("Profit", "sum"), Customers=("Customer ID", "nunique"))
reg["Margin %"] = reg["Profit"] / reg["Revenue"] * 100
reg.to_csv(OUT / "region_performance.csv")
plt.figure(figsize=(9, 5))
sns.barplot(x=reg.sort_values("Revenue", ascending=False).index,
            y=reg.sort_values("Revenue", ascending=False)["Revenue"], palette=PAL)
plt.xticks(rotation=20)
plt.ylabel("Revenue")
save("Revenue by Region", "region_revenue")

# ---- CUSTOMER BEHAVIOUR ----
plt.figure(figsize=(8, 8))
seg = df.groupby("Segment")["Sales"].sum()
plt.pie(seg, labels=seg.index, autopct="%1.1f%%", colors=sns.color_palette(PAL, len(seg)), startangle=90)
save("Revenue Share by Customer Segment", "segment_share")

plt.figure(figsize=(9, 5))
ag = df.groupby("Age Group").agg(Revenue=("Sales", "sum"), AOV=("Sales", "mean")).reindex(["18-24", "25-34", "35-44", "45-54", "55+"])
sns.barplot(x=ag.index, y=ag["AOV"], palette=PAL)
plt.ylabel("Average order value (USD)")
save("Average Order Value by Age Group", "aov_age")

plt.figure(figsize=(9, 5))
ch = df.groupby("Marketing Channel").agg(Revenue=("Sales", "sum"), Margin=("Profit Margin %", "mean")).sort_values("Revenue")
sns.barplot(x=ch["Revenue"], y=ch.index, palette=PAL)
plt.xlabel("Revenue")
save("Revenue by Marketing Channel", "channel_revenue")

plt.figure(figsize=(9, 5))
sns.countplot(data=df, x="Payment Method", order=df["Payment Method"].value_counts().index, palette=PAL)
plt.xticks(rotation=20)
save("Orders by Payment Method", "payment")

plt.figure(figsize=(9, 5))
cust_tbl = df.groupby("Customer ID").agg(Orders=("Order ID", "nunique"), Revenue=("Sales", "sum"))
sns.histplot(cust_tbl["Orders"], bins=range(1, int(cust_tbl["Orders"].max()) + 2), color=BLUE)
plt.xlabel("Orders per customer")
save("Customer Purchase Frequency Distribution", "frequency")

plt.figure(figsize=(9, 5))
cs = cust_tbl["Revenue"].sort_values(ascending=False).reset_index(drop=True)
cum = cs.cumsum() / cs.sum() * 100
plt.plot(np.arange(1, len(cs) + 1) / len(cs) * 100, cum, color=BLUE, lw=2)
plt.axvline(20, ls="--", color="grey")
plt.xlabel("% of customers (ranked by revenue)")
plt.ylabel("Cumulative % of revenue")
top20_share = cum.iloc[int(len(cs) * 0.2)]
save("Pareto: Customer Revenue Concentration", "pareto")

plt.figure(figsize=(9, 5))
sns.barplot(data=df, x="Shipping Mode", y="Profit", palette=PAL, errorbar=None)
plt.ylabel("Average profit per order")
save("Average Profit per Order by Shipping Mode", "shipping_profit")

plt.figure(figsize=(8, 5))
sns.boxplot(data=df, x="Category", y="Sales", showfliers=False, palette=PAL)
plt.xticks(rotation=25)
save("Order Value Distribution by Category (outlier analysis)", "boxplot")

print(f"\nTop 20% of customers generate {top20_share:.1f}% of revenue")
print(f"Created {chart_no[0]} charts in {CH}")
pd.Series({"top20_share": top20_share}).to_json(OUT / "extra_metrics.json")
