"""
STEP 4 - BONUS: MACHINE LEARNING
 (a) Customer segmentation (RFM + K-Means)
 (b) Customer churn prediction (Random Forest / Logistic Regression)
 (c) Future sales forecast (Gradient Boosting on monthly data, 6-month horizon)
 (d) Product demand forecast (next-quarter units by product, simple trend model)
"""
import warnings
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import seaborn as sns
from pathlib import Path
from sklearn.cluster import KMeans
from sklearn.preprocessing import StandardScaler
from sklearn.ensemble import RandomForestClassifier, GradientBoostingRegressor
from sklearn.linear_model import LogisticRegression, LinearRegression
from sklearn.model_selection import train_test_split
from sklearn.metrics import (accuracy_score, roc_auc_score, classification_report, confusion_matrix,
                             mean_absolute_error, mean_absolute_percentage_error)

warnings.filterwarnings("ignore")
BASE = Path(__file__).parent
OUT, CH = BASE / "outputs", BASE / "charts"
df = pd.read_csv(BASE / "data" / "clean_orders.csv", parse_dates=["Order Date", "Ship Date"])
sns.set_theme(style="whitegrid")
report = []


def log(s=""):
    print(s)
    report.append(s)


# ============================================================ (a) RFM SEGMENTATION
snapshot = df["Order Date"].max() + pd.Timedelta(days=1)
rfm = df.groupby("Customer ID").agg(Recency=("Order Date", lambda s: (snapshot - s.max()).days),
                                    Frequency=("Order ID", "nunique"),
                                    Monetary=("Sales", "sum"),
                                    Profit=("Profit", "sum"),
                                    AvgRating=("Rating", "mean"),
                                    AvgDiscount=("Discount", "mean")).reset_index()
X = StandardScaler().fit_transform(np.log1p(rfm[["Recency", "Frequency", "Monetary"]]))
k = 4
km = KMeans(n_clusters=k, n_init=10, random_state=42).fit(X)
rfm["Cluster"] = km.labels_
prof = rfm.groupby("Cluster")[["Recency", "Frequency", "Monetary"]].mean()


def name_cluster(c):
    r = prof.loc[c]
    if r["Monetary"] >= prof["Monetary"].quantile(.75) and r["Recency"] <= prof["Recency"].median():
        return "Champions"
    if r["Recency"] >= prof["Recency"].quantile(.75):
        return "Lost / Churned"
    if r["Frequency"] >= prof["Frequency"].median():
        return "Loyal"
    return "At Risk / Occasional"


names = {c: name_cluster(c) for c in prof.index}
# make sure names are unique
seen = {}
for c, n in sorted(names.items(), key=lambda x: -prof.loc[x[0], "Monetary"]):
    seen[n] = seen.get(n, 0) + 1
    if seen[n] > 1:
        names[c] = f"{n} {seen[n]}"
rfm["Segment"] = rfm["Cluster"].map(names)
seg_sum = rfm.groupby("Segment").agg(Customers=("Customer ID", "count"), Avg_Recency_Days=("Recency", "mean"),
                                     Avg_Orders=("Frequency", "mean"), Avg_Spend=("Monetary", "mean"),
                                     Total_Revenue=("Monetary", "sum")).round(1)
seg_sum["Revenue Share %"] = (seg_sum["Total_Revenue"] / seg_sum["Total_Revenue"].sum() * 100).round(1)
log("=== (a) CUSTOMER SEGMENTATION (RFM + K-Means, k=4) ===")
log(seg_sum.sort_values("Total_Revenue", ascending=False).to_string())
rfm.to_csv(OUT / "customer_segments_rfm.csv", index=False)
seg_sum.to_csv(OUT / "segment_summary.csv")

fig, ax = plt.subplots(1, 2, figsize=(13, 5))
sns.scatterplot(data=rfm, x="Recency", y="Monetary", hue="Segment", ax=ax[0], alpha=.7)
ax[0].set_yscale("log")
ax[0].set_title("RFM Segments: Recency vs Monetary")
seg_sum["Revenue Share %"].sort_values().plot(kind="barh", ax=ax[1], color="#2563eb")
ax[1].set_title("Revenue share by RFM segment (%)")
plt.tight_layout()
plt.savefig(CH / "22_rfm_segments.png", dpi=130)
plt.close()

# ============================================================ (b) CHURN PREDICTION
# Time-based design to avoid leakage: features from orders BEFORE cutoff, label = no purchase in 6 months AFTER cutoff
cutoff = pd.Timestamp("2024-06-30")
hist = df[df["Order Date"] <= cutoff]
future = df[df["Order Date"] > cutoff]
f = hist.groupby("Customer ID").agg(
    recency=("Order Date", lambda s: (cutoff - s.max()).days),
    frequency=("Order ID", "nunique"),
    monetary=("Sales", "sum"),
    avg_order=("Sales", "mean"),
    avg_profit=("Profit", "mean"),
    avg_discount=("Discount", "mean"),
    avg_rating=("Rating", "mean"),
    tenure=("Order Date", lambda s: (cutoff - s.min()).days),
    categories=("Category", "nunique"),
    age=("Customer Age", "first"),
    loss_share=("Is Loss", "mean"),
).reset_index()
f["churn"] = (~f["Customer ID"].isin(future["Customer ID"].unique())).astype(int)
Xc = f.drop(columns=["Customer ID", "churn"])
yc = f["churn"]
Xtr, Xte, ytr, yte = train_test_split(Xc, yc, test_size=0.25, stratify=yc, random_state=42)
rf = RandomForestClassifier(n_estimators=300, max_depth=7, class_weight="balanced", random_state=42).fit(Xtr, ytr)
lr = LogisticRegression(max_iter=2000, class_weight="balanced").fit(StandardScaler().fit(Xtr).transform(Xtr), ytr)
p_rf = rf.predict_proba(Xte)[:, 1]
p_lr = lr.predict_proba(StandardScaler().fit(Xtr).transform(Xte))[:, 1]
log("\n=== (b) CHURN PREDICTION (churn = no purchase in the 6 months after 30-Jun-2024) ===")
log(f"Customers modelled: {len(f):,} | churn rate: {yc.mean()*100:.1f}%")
log(f"Logistic Regression  AUC={roc_auc_score(yte, p_lr):.3f}")
log(f"Random Forest        AUC={roc_auc_score(yte, p_rf):.3f}  Accuracy={accuracy_score(yte, rf.predict(Xte)):.3f}")
log(classification_report(yte, rf.predict(Xte), target_names=["Retained", "Churned"]))
imp = pd.Series(rf.feature_importances_, index=Xc.columns).sort_values()
plt.figure(figsize=(8, 5))
imp.plot(kind="barh", color="#2563eb")
plt.title("Churn model: feature importance (Random Forest)")
plt.tight_layout()
plt.savefig(CH / "23_churn_feature_importance.png", dpi=130)
plt.close()
cm = confusion_matrix(yte, rf.predict(Xte))
plt.figure(figsize=(5, 4))
sns.heatmap(cm, annot=True, fmt="d", cmap="Blues", xticklabels=["Retained", "Churned"], yticklabels=["Retained", "Churned"])
plt.title("Churn model: confusion matrix")
plt.tight_layout()
plt.savefig(CH / "24_churn_confusion.png", dpi=130)
plt.close()
f["churn_probability"] = rf.predict_proba(Xc)[:, 1]
at_risk = f.merge(rfm[["Customer ID", "Segment"]], on="Customer ID").sort_values("monetary", ascending=False)
at_risk[at_risk["churn_probability"] > 0.6].head(100).to_csv(OUT / "high_value_at_risk_customers.csv", index=False)
log(f"Top feature drivers: {', '.join(imp.index[::-1][:3])}")

# ============================================================ (c) SALES FORECAST
ms = df.groupby("YearMonth")["Sales"].sum().reset_index()
ms["t"] = np.arange(len(ms))
ms["month"] = pd.to_datetime(ms["YearMonth"]).dt.month
# Seasonal-level model: forecast = recent level x seasonal index (trend alone ignores Nov/Dec peaks)
# Seasonal index = average ratio of each month to its own year's average
ms["year"] = pd.to_datetime(ms["YearMonth"]).dt.year
ms["ratio"] = ms["Sales"] / ms.groupby("year")["Sales"].transform("mean")
season = ms.groupby("month")["ratio"].mean()


def seasonal_forecast(history, months):
    level = history["Sales"].iloc[-12:].mean()
    return np.array([level * season[m] for m in months])


test = ms.iloc[-6:]
pred_bt = seasonal_forecast(ms.iloc[:-6], test["month"])
mae_bt = mean_absolute_error(test["Sales"], pred_bt)
mape_bt = mean_absolute_percentage_error(test["Sales"], pred_bt) * 100
naive = np.repeat(ms.iloc[:-6]["Sales"].iloc[-12:].mean(), 6)
log(f"(c) Seasonal-level model back-test (last 6 months): MAE=${mae_bt:,.0f}, MAPE={mape_bt:.1f}%")
log(f"    Naive average baseline:                          MAE=${mean_absolute_error(test['Sales'], naive):,.0f}, "
    f"MAPE={mean_absolute_percentage_error(test['Sales'], naive)*100:.1f}%")
fut_dates = pd.date_range(pd.to_datetime(ms["YearMonth"].iloc[-1]) + pd.offsets.MonthBegin(1), periods=6, freq="MS")
fut = pd.DataFrame({"YearMonth": fut_dates.strftime("%Y-%m"), "month": fut_dates.month})
fut["Forecast"] = seasonal_forecast(ms, fut["month"])
fut[["YearMonth", "Forecast"]].round(0).to_csv(OUT / "sales_forecast_next_6_months.csv", index=False)
log("\n=== (c) SALES FORECAST: next 6 months ===")
log(fut[["YearMonth", "Forecast"]].round(0).to_string(index=False))
plt.figure(figsize=(12, 5))
plt.plot(ms["YearMonth"], ms["Sales"], marker="o", label="Actual", color="#2563eb")
plt.plot(fut["YearMonth"], fut["Forecast"], marker="o", ls="--", label="Forecast", color="#f59e0b")
plt.xticks(rotation=70)
plt.legend()
plt.title("Monthly revenue: actual and 6-month forecast")
plt.tight_layout()
plt.savefig(CH / "25_sales_forecast.png", dpi=130)
plt.close()

# ============================================================ (d) PRODUCT DEMAND
pq = df.groupby(["Product", df["Order Date"].dt.to_period("Q")])["Quantity"].sum().unstack(fill_value=0)
qseason = pq.sum().groupby(pq.columns.quarter).mean()
qseason = qseason / qseason.mean()
next_q = (pq.columns[-1] + 1).quarter
rows = []
for p_name, r in pq.iterrows():
    level = r.values[-4:].mean()  # last 4 quarters = one full seasonal cycle
    rows.append((p_name, int(r.values[-1]), max(0, round(level * qseason[next_q]))))
dem = pd.DataFrame(rows, columns=["Product", "Units_Last_Quarter", "Forecast_Units_Next_Quarter"])
dem["Change %"] = ((dem["Forecast_Units_Next_Quarter"] / dem["Units_Last_Quarter"].replace(0, np.nan) - 1) * 100).round(1)
dem = dem.sort_values("Forecast_Units_Next_Quarter", ascending=False)
dem.to_csv(OUT / "product_demand_forecast.csv", index=False)
log("\n=== (d) PRODUCT DEMAND FORECAST (top 8 by next-quarter units) ===")
log(dem.head(8).to_string(index=False))

(OUT / "ml_report.txt").write_text("\n".join(report), encoding="utf-8")
print("\nSaved ML outputs.")
