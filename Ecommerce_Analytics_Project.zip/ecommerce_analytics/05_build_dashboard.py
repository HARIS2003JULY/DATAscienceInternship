"""
STEP 5 - PART 4: INTERACTIVE DASHBOARD
Builds ONE self-contained file: dashboard.html  (works offline, double-click to open).
6 pages: Executive Summary, Sales, Product, Customer, Regional, Profit.
Slicers: Year, Region, Category, Customer Segment (apply to every page).
"""
import json
from pathlib import Path
import pandas as pd
import plotly

BASE = Path(__file__).parent
df = pd.read_csv(BASE / "data" / "clean_orders.csv", parse_dates=["Order Date"])

cols = {
    "ym": "YearMonth", "yr": "Year", "q": "Quarter", "reg": "Region", "city": "City", "cat": "Category",
    "prod": "Product", "seg": "Segment", "ch": "Marketing Channel", "ship": "Shipping Mode",
    "pay": "Payment Method", "age": "Age Group", "disc": "Discount Band", "dow": "Day of Week",
    "cid": "Customer ID", "oid": "Order ID", "gen": "Gender",
}
nums = {"s": "Sales", "p": "Profit", "qty": "Quantity", "rt": "Rating", "loss": "Is Loss"}
records = pd.DataFrame({k: df[v] for k, v in cols.items()})
for k, v in nums.items():
    records[k] = df[v].round(2)
data_json = records.to_json(orient="records")
plotly_js = Path(plotly.__file__).parent / "package_data" / "plotly.min.js"
plotly_src = plotly_js.read_text(encoding="utf-8")

HTML = r"""<!DOCTYPE html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>E-Commerce Business Analytics Dashboard</title>
<style>
:root{--bg:#f4f6fb;--card:#fff;--ink:#111827;--mute:#6b7280;--blue:#2563eb;--green:#16a34a;--red:#dc2626;--amber:#f59e0b;--line:#e5e7eb}
*{box-sizing:border-box}body{margin:0;font-family:Segoe UI,Roboto,Helvetica,Arial,sans-serif;background:var(--bg);color:var(--ink)}
header{background:linear-gradient(90deg,#1e3a8a,#2563eb);color:#fff;padding:14px 24px}
header h1{margin:0;font-size:20px}header p{margin:2px 0 0;font-size:12px;opacity:.85}
.filters{display:flex;gap:14px;flex-wrap:wrap;padding:12px 24px;background:#fff;border-bottom:1px solid var(--line);position:sticky;top:0;z-index:10;align-items:end}
.filters label{font-size:11px;color:var(--mute);display:flex;flex-direction:column;gap:3px;text-transform:uppercase;letter-spacing:.04em}
.filters select{padding:6px 10px;border:1px solid var(--line);border-radius:6px;font-size:13px;min-width:140px}
.filters button{padding:7px 14px;border:0;border-radius:6px;background:var(--blue);color:#fff;cursor:pointer;font-size:13px}
nav{display:flex;gap:4px;padding:10px 24px 0;flex-wrap:wrap}
nav button{border:0;background:#e5e7eb;padding:9px 16px;border-radius:8px 8px 0 0;cursor:pointer;font-size:13px;color:#374151}
nav button.active{background:#fff;color:var(--blue);font-weight:600}
main{padding:0 24px 30px}.page{display:none;background:#fff;padding:16px;border-radius:0 8px 8px 8px}.page.active{display:block}
.kpis{display:grid;grid-template-columns:repeat(auto-fit,minmax(160px,1fr));gap:12px;margin-bottom:14px}
.kpi{background:var(--card);border:1px solid var(--line);border-left:4px solid var(--blue);border-radius:8px;padding:12px}
.kpi .l{font-size:11px;color:var(--mute);text-transform:uppercase;letter-spacing:.04em}.kpi .v{font-size:23px;font-weight:700;margin-top:4px}
.kpi .d{font-size:11px;margin-top:2px;color:var(--mute)}
.grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(420px,1fr));gap:14px}
.box{border:1px solid var(--line);border-radius:8px;padding:6px;background:#fff;min-height:340px}
.box.wide{grid-column:1/-1}
.note{background:#eff6ff;border-left:4px solid var(--blue);padding:10px 14px;border-radius:6px;font-size:13px;margin-bottom:14px}
table{border-collapse:collapse;width:100%;font-size:13px}th,td{padding:7px 10px;border-bottom:1px solid var(--line);text-align:right}th:first-child,td:first-child{text-align:left}th{background:#f9fafb}
@media(max-width:560px){.grid{grid-template-columns:1fr}}
</style></head><body>
<header><h1>E-Commerce Business Analytics Dashboard</h1><p>Orders Jan 2023 - Dec 2024 &nbsp;|&nbsp; Use the slicers below to filter every page</p></header>
<div class="filters">
<label>Year<select id="f_yr"></select></label><label>Region<select id="f_reg"></select></label>
<label>Category<select id="f_cat"></select></label><label>Customer segment<select id="f_seg"></select></label>
<button onclick="resetF()">Reset filters</button><span id="count" style="font-size:12px;color:#6b7280"></span></div>
<nav id="nav"></nav>
<main>
<section class="page" id="p_exec"><div class="kpis" id="k_exec"></div><div class="note" id="n_exec"></div>
<div class="grid"><div class="box wide" id="c_e1"></div><div class="box" id="c_e2"></div><div class="box" id="c_e3"></div></div></section>
<section class="page" id="p_sales"><div class="grid">
<div class="box" id="c_s1"></div><div class="box" id="c_s2"></div><div class="box" id="c_s3"></div>
<div class="box" id="c_s4"></div><div class="box" id="c_s5"></div><div class="box" id="c_s6"></div></div></section>
<section class="page" id="p_prod"><div class="grid">
<div class="box" id="c_p1"></div><div class="box" id="c_p2"></div><div class="box" id="c_p3"></div>
<div class="box" id="c_p4"></div><div class="box wide" id="c_p5"></div></div></section>
<section class="page" id="p_cust"><div class="kpis" id="k_cust"></div><div class="grid">
<div class="box" id="c_c1"></div><div class="box" id="c_c2"></div><div class="box" id="c_c3"></div>
<div class="box" id="c_c4"></div><div class="box" id="c_c5"></div><div class="box" id="c_c6"></div>
<div class="box wide"><h4 style="margin:8px">Top 10 customers by revenue</h4><div id="t_cust"></div></div></div></section>
<section class="page" id="p_reg"><div class="grid">
<div class="box" id="c_r1"></div><div class="box" id="c_r2"></div><div class="box" id="c_r3"></div><div class="box" id="c_r4"></div>
<div class="box wide" id="c_r5"></div></div></section>
<section class="page" id="p_prof"><div class="kpis" id="k_prof"></div><div class="grid">
<div class="box" id="c_f1"></div><div class="box" id="c_f2"></div><div class="box" id="c_f3"></div>
<div class="box" id="c_f4"></div><div class="box wide" id="c_f5"></div></div></section>
</main>
<script>/*PLOTLY*/</script>
<script>
const DATA = /*DATA*/;
const PAGES=[["exec","Executive Summary"],["sales","Sales Analysis"],["prod","Product Analysis"],["cust","Customer Analysis"],["reg","Regional Analysis"],["prof","Profit Analysis"]];
const COL=["#2563eb","#16a34a","#f59e0b","#dc2626","#7c3aed","#0891b2","#db2777","#65a30d"];
const F={yr:"All",reg:"All",cat:"All",seg:"All"};
const uniq=(k)=>[...new Set(DATA.map(d=>d[k]))].sort();
const sum=(a,f)=>a.reduce((t,d)=>t+f(d),0);
const money=v=>"$"+Math.round(v).toLocaleString();
const pct=v=>v.toFixed(1)+"%";
function rows(){return DATA.filter(d=>(F.yr==="All"||d.yr==F.yr)&&(F.reg==="All"||d.reg===F.reg)&&(F.cat==="All"||d.cat===F.cat)&&(F.seg==="All"||d.seg===F.seg));}
function group(r,key,agg){const m=new Map();r.forEach(d=>{const k=d[key];if(!m.has(k))m.set(k,[]);m.get(k).push(d);});
 return [...m.entries()].map(([k,a])=>({k,...agg(a)}));}
const std=a=>({rev:sum(a,d=>d.s),prof:sum(a,d=>d.p),n:new Set(a.map(d=>d.oid)).size,cust:new Set(a.map(d=>d.cid)).size,qty:sum(a,d=>d.qty),loss:sum(a,d=>d.loss),cnt:a.length,aov:sum(a,d=>d.s)/a.length,rt:sum(a,d=>d.rt)/a.length});
const LAY=(t,extra={})=>Object.assign({title:{text:t,font:{size:14}},margin:{t:40,l:55,r:15,b:50},font:{family:"Segoe UI, Arial",size:11},paper_bgcolor:"#fff",plot_bgcolor:"#fff",legend:{orientation:"h",y:-0.25}},extra);
const CFG={responsive:true,displaylogo:false};
const plot=(id,tr,t,extra)=>Plotly.react(id,tr,LAY(t,extra),CFG);
function kpi(l,v,d,c){return `<div class="kpi" ${c?`style="border-left-color:${c}"`:""}><div class="l">${l}</div><div class="v">${v}</div><div class="d">${d||""}</div></div>`;}
function bar(x,y,name,color,orient){return {type:"bar",x:orient==="h"?y:x,y:orient==="h"?x:y,name,orientation:orient,marker:{color}};}
const sortDesc=(a,f)=>a.slice().sort((x,y)=>f(y)-f(x));

function render(){
 const r=rows(); document.getElementById("count").textContent=r.length.toLocaleString()+" order lines selected";
 if(!r.length){return;}
 const t=std(r), margin=t.prof/t.rev*100;
 // growth (only meaningful when all years included)
 let growth="n/a (set Year = All)", gcol="";
 const y23=sum(r.filter(d=>d.yr==2023),d=>d.s),y24=sum(r.filter(d=>d.yr==2024),d=>d.s);
 if(y23>0&&y24>0){const g=(y24/y23-1)*100;growth=(g>=0?"+":"")+pct(g);}
 // ---------- EXEC
 document.getElementById("k_exec").innerHTML=kpi("Total revenue",money(t.rev))+kpi("Total profit",money(t.prof),"",COL[1])+kpi("Total orders",t.n.toLocaleString())+kpi("Avg order value",money(t.aov).replace(/^\$/,"$")+"" ,"",COL[2])+kpi("Profit margin",pct(margin),"",COL[4])+kpi("Customers",t.cust.toLocaleString(),"",COL[5])+kpi("Revenue growth 24 vs 23",growth,"",COL[3]);
 const mo=group(r,"ym",std).sort((a,b)=>a.k<b.k?-1:1);
 plot("c_e1",[{type:"scatter",mode:"lines+markers",x:mo.map(d=>d.k),y:mo.map(d=>d.rev),name:"Revenue",line:{color:COL[0]}},{type:"scatter",mode:"lines+markers",x:mo.map(d=>d.k),y:mo.map(d=>d.prof),name:"Profit",line:{color:COL[1]}}],"Monthly revenue & profit");
 const ca=group(r,"cat",std);
 plot("c_e2",[{type:"pie",labels:ca.map(d=>d.k),values:ca.map(d=>d.rev),hole:.5,marker:{colors:COL}}],"Revenue share by category");
 const rg=group(r,"reg",std);
 plot("c_e3",[bar(rg.map(d=>d.k),rg.map(d=>d.rev),"Revenue",COL[0]),bar(rg.map(d=>d.k),rg.map(d=>d.prof),"Profit",COL[1])],"Revenue & profit by region",{barmode:"group"});
 const best=sortDesc(ca,d=>d.prof/d.rev)[0], worst=sortDesc(ca,d=>d.prof/d.rev).slice(-1)[0], topc=sortDesc(ca,d=>d.rev)[0];
 document.getElementById("n_exec").innerHTML=`<b>Headline:</b> ${topc.k} is the largest category (${money(topc.rev)}). Best margin: <b>${best.k}</b> (${pct(best.prof/best.rev*100)}); weakest margin: <b>${worst.k}</b> (${pct(worst.prof/worst.rev*100)}). ${pct(t.loss/t.cnt*100)} of order lines lose money.`;
 // ---------- SALES
 plot("c_s1",[bar(mo.map(d=>d.k),mo.map(d=>d.n),"Orders",COL[0])],"Orders per month");
 const qt=group(r,"q",std).sort((a,b)=>a.k<b.k?-1:1);
 plot("c_s2",[bar(qt.map(d=>d.k),qt.map(d=>d.rev),"Revenue",COL[4])],"Revenue by quarter (all selected years)");
 const dw=["Monday","Tuesday","Wednesday","Thursday","Friday","Saturday","Sunday"],dg=group(r,"dow",std);
 plot("c_s3",[bar(dw,dw.map(x=>(dg.find(d=>d.k===x)||{rev:0}).rev),"Revenue",COL[5])],"Revenue by day of week");
 const ch=sortDesc(group(r,"ch",std),d=>d.rev);
 plot("c_s4",[bar(ch.map(d=>d.k),ch.map(d=>d.rev),"Revenue",COL[2],"h")],"Revenue by marketing channel",{margin:{t:40,l:110,r:15,b:40}});
 const sh=group(r,"ship",std);
 plot("c_s5",[bar(sh.map(d=>d.k),sh.map(d=>d.aov),"AOV",COL[6])],"Average order value by shipping mode");
 const pm=sortDesc(group(r,"pay",std),d=>d.cnt);
 plot("c_s6",[{type:"pie",labels:pm.map(d=>d.k),values:pm.map(d=>d.cnt),marker:{colors:COL}}],"Orders by payment method");
 // ---------- PRODUCT
 const pr=group(r,"prod",std);
 const top=sortDesc(pr,d=>d.prof).slice(0,10).reverse(), bot=pr.slice().sort((a,b)=>a.prof-b.prof).slice(0,10);
 plot("c_p1",[bar(top.map(d=>d.k),top.map(d=>d.prof),"Profit",COL[1],"h")],"Top 10 products by profit",{margin:{t:40,l:110,r:15,b:40}});
 plot("c_p2",[bar(bot.map(d=>d.k),bot.map(d=>d.prof),"Profit",COL[3],"h")],"Bottom 10 products by profit",{margin:{t:40,l:110,r:15,b:40}});
 const cm=sortDesc(ca,d=>d.prof/d.rev);
 plot("c_p3",[bar(cm.map(d=>d.k),cm.map(d=>d.prof/d.rev*100),"Margin %",COL[4])],"Profit margin % by category");
 const di=["No Discount","1-10%","11-20%",">20%"],dgp=group(r,"disc",std);
 plot("c_p4",[bar(di,di.map(x=>{const g=dgp.find(d=>d.k===x);return g?g.prof/g.rev*100:0;}),"Margin %",COL[2])],"Profit margin % by discount level");
 const catList=[...new Set(r.map(d=>d.cat))];
 plot("c_p5",catList.map((c,i)=>{const p=pr.filter(x=>r.find(d=>d.prod===x.k&&d.cat===c));return {type:"scatter",mode:"markers",name:c,x:p.map(d=>d.rev),y:p.map(d=>d.prof/d.rev*100),text:p.map(d=>d.k),marker:{size:p.map(d=>Math.max(8,Math.sqrt(d.qty)*1.6)),color:COL[i%COL.length],opacity:.8}};}),"Product matrix: revenue (x) vs margin % (y), bubble = units",{xaxis:{title:"Revenue"},yaxis:{title:"Margin %"}});
 // ---------- CUSTOMER
 const cg=group(r,"cid",std);
 const rep=cg.filter(d=>d.n>1).length/cg.length*100;
 document.getElementById("k_cust").innerHTML=kpi("Customers",cg.length.toLocaleString())+kpi("Revenue / customer",money(t.rev/cg.length),"",COL[1])+kpi("Orders / customer",(t.n/cg.length).toFixed(1),"",COL[2])+kpi("Repeat customers",pct(rep),"",COL[4])+kpi("Avg rating",t.rt.toFixed(2)+" / 5","",COL[5]);
 const sg=group(r,"seg",std);
 plot("c_c1",[{type:"pie",labels:sg.map(d=>d.k),values:sg.map(d=>d.rev),hole:.45,marker:{colors:COL}}],"Revenue by customer segment");
 const ag=["18-24","25-34","35-44","45-54","55+"],agg=group(r,"age",std);
 plot("c_c2",[bar(ag,ag.map(x=>(agg.find(d=>d.k===x)||{aov:0}).aov),"AOV",COL[0])],"Average order value by age group");
 const gn=group(r,"gen",std);
 plot("c_c3",[bar(gn.map(d=>d.k),gn.map(d=>d.rev),"Revenue",COL[6])],"Revenue by gender");
 const fr=new Map();cg.forEach(d=>{const b=Math.min(d.n,12);fr.set(b,(fr.get(b)||0)+1);});
 const fk=[...fr.keys()].sort((a,b)=>a-b);
 plot("c_c4",[bar(fk.map(k=>k===12?"12+":String(k)),fk.map(k=>fr.get(k)),"Customers",COL[5])],"Customers by number of orders");
 const rts=[1,2,3,4,5].map(x=>r.filter(d=>Math.round(d.rt)===x).length);
 plot("c_c5",[bar(["1","2","3","4","5"],rts,"Orders",COL[2])],"Rating distribution");
 const cs=sortDesc(cg,d=>d.rev);let cum=0;const tot=t.rev;
 const px=[],py=[];cs.forEach((d,i)=>{cum+=d.rev;if(i%Math.max(1,Math.floor(cs.length/100))===0){px.push((i+1)/cs.length*100);py.push(cum/tot*100);}});
 plot("c_c6",[{type:"scatter",mode:"lines",x:px,y:py,line:{color:COL[0],width:3}}],"Pareto: % of customers vs % of revenue",{xaxis:{title:"% customers"},yaxis:{title:"% revenue"}});
 document.getElementById("t_cust").innerHTML="<table><tr><th>Customer</th><th>Orders</th><th>Revenue</th><th>Profit</th></tr>"+cs.slice(0,10).map(d=>`<tr><td>${d.k}</td><td>${d.n}</td><td>${money(d.rev)}</td><td>${money(d.prof)}</td></tr>`).join("")+"</table>";
 // ---------- REGION
 plot("c_r1",[bar(rg.map(d=>d.k),rg.map(d=>d.rev),"Revenue",COL[0])],"Revenue by region");
 plot("c_r2",[bar(rg.map(d=>d.k),rg.map(d=>d.prof/d.rev*100),"Margin %",COL[1])],"Profit margin % by region");
 const ci=sortDesc(group(r,"city",std),d=>d.rev).slice(0,10).reverse();
 plot("c_r3",[bar(ci.map(d=>d.k),ci.map(d=>d.rev),"Revenue",COL[4],"h")],"Top 10 cities by revenue",{margin:{t:40,l:110,r:15,b:40}});
 plot("c_r4",[bar(rg.map(d=>d.k),rg.map(d=>d.cust),"Customers",COL[5])],"Customers by region");
 const regs=rg.map(d=>d.k),cats=ca.map(d=>d.k);
 const z=regs.map(a=>cats.map(b=>sum(r.filter(d=>d.reg===a&&d.cat===b),d=>d.s)));
 plot("c_r5",[{type:"heatmap",x:cats,y:regs,z,colorscale:"Blues"}],"Revenue heatmap: region x category");
 // ---------- PROFIT
 document.getElementById("k_prof").innerHTML=kpi("Total profit",money(t.prof),"",COL[1])+kpi("Profit margin",pct(margin),"",COL[4])+kpi("Profit / order",money(t.prof/t.n),"",COL[0])+kpi("Loss-making lines",pct(t.loss/t.cnt*100),"",COL[3])+kpi("Profit lost on loss lines",money(-sum(r.filter(d=>d.p<0),d=>d.p)),"",COL[3]);
 plot("c_f1",[bar(mo.map(d=>d.k),mo.map(d=>d.prof),"Profit",COL[1])],"Monthly profit");
 plot("c_f2",[bar(cm.map(d=>d.k),cm.map(d=>d.loss/d.cnt*100),"Loss %",COL[3])],"% of order lines that lose money, by category");
 plot("c_f3",[bar(sh.map(d=>d.k),sh.map(d=>d.prof/d.cnt),"Profit/line",COL[2])],"Average profit per order line by shipping mode");
 plot("c_f4",[bar(di,di.map(x=>{const g=dgp.find(d=>d.k===x);return g?g.loss/g.cnt*100:0;}),"Loss %",COL[3])],"% loss-making lines by discount level");
 const lp=sortDesc(pr,d=>d.loss/d.cnt).slice(0,12);
 plot("c_f5",[bar(lp.map(d=>d.k),lp.map(d=>d.loss/d.cnt*100),"Loss %",COL[3])],"Products with the highest share of loss-making lines");
}
// ---------- init
["yr","reg","cat","seg"].forEach(k=>{const s=document.getElementById("f_"+k);s.innerHTML="<option>All</option>"+uniq(k).map(v=>`<option>${v}</option>`).join("");s.onchange=()=>{F[k]=s.value;render();};});
function resetF(){["yr","reg","cat","seg"].forEach(k=>{F[k]="All";document.getElementById("f_"+k).value="All";});render();}
const nav=document.getElementById("nav");
PAGES.forEach(([id,name],i)=>{const b=document.createElement("button");b.textContent=name;b.onclick=()=>show(id);b.id="b_"+id;nav.appendChild(b);});
function show(id){PAGES.forEach(([p])=>{document.getElementById("p_"+p).classList.toggle("active",p===id);document.getElementById("b_"+p).classList.toggle("active",p===id);});
 setTimeout(()=>{render();window.dispatchEvent(new Event("resize"));},30);}
show("exec");
</script></body></html>"""

html = HTML.replace("/*PLOTLY*/", plotly_src).replace("/*DATA*/", data_json)
(BASE / "dashboard.html").write_text(html, encoding="utf-8")
print(f"Dashboard written: {BASE/'dashboard.html'}  ({len(html)/1e6:.1f} MB)")
