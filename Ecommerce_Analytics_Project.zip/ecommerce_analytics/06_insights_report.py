"""
STEP 6 - PART 5: BUSINESS INSIGHTS & RECOMMENDATIONS
Every number below is computed from the clean data (nothing is hard-coded), so the
report stays correct if you replace the dataset with your own.
Output: outputs/insights_and_recommendations.md
"""
import pandas as pd
import numpy as np
from pathlib import Path

BASE = Path(__file__).parent
df = pd.read_csv(BASE / "data" / "clean_orders.csv", parse_dates=["Order Date"])
seg = pd.read_csv(BASE / "outputs" / "customer_segments_rfm.csv")
fc = pd.read_csv(BASE / "outputs" / "sales_forecast_next_6_months.csv")
risk = pd.read_csv(BASE / "outputs" / "high_value_at_risk_customers.csv")


def agg(k):
    t = df.groupby(k).agg(rev=("Sales", "sum"), prof=("Profit", "sum"), n=("Order ID", "count"),
                          loss=("Is Loss", "mean"), aov=("Sales", "mean"), cust=("Customer ID", "nunique"))
    t["m"] = t["prof"] / t["rev"] * 100
    return t


def M(v):
    return f"${v:,.0f}"


tot_rev, tot_prof = df["Sales"].sum(), df["Profit"].sum()
margin = tot_prof / tot_rev * 100
cat, reg, disc, ship = agg("Category"), agg("Region"), agg("Discount Band"), agg("Shipping Mode")
prod, chan, yr = agg("Product"), agg("Marketing Channel"), agg("Year")
seg_t = seg.groupby("Segment").agg(c=("Customer ID", "count"), rev=("Monetary", "sum"))
seg_t["share"] = seg_t["rev"] / seg_t["rev"].sum() * 100

top_cat = cat["rev"].idxmax()
elec = cat.loc["Electronics"]
best_m = cat["m"].idxmax()
worst_m = cat["m"].idxmin()
lap = prod.loc["Laptop"]
hi_disc = disc.loc[">20%"]
mid_disc = disc.loc["11-20%"]
no_disc = disc.loc["No Discount"]
d_hi = df[df["Discount"] > 0.10]
loss_total = df.loc[df["Profit"] < 0, "Profit"].sum()
rev_g = (yr.loc[2024, "rev"] / yr.loc[2023, "rev"] - 1) * 100
months = df.groupby("Month Name")["Sales"].sum().sort_values(ascending=False)
nd = months.index[:2]
q4_share = df[df["Quarter"] == "Q4"]["Sales"].sum() / tot_rev * 100
cust_rev = df.groupby("Customer ID")["Sales"].sum().sort_values(ascending=False)
top20 = cust_rev.head(int(len(cust_rev) * .2)).sum() / cust_rev.sum() * 100
cust_orders = df.groupby("Customer ID")["Order ID"].nunique()
repeat = (cust_orders > 1).mean() * 100
champ = seg_t.loc["Champions"]
lost = seg_t.loc["Lost / Churned"]
dow = df.groupby("Day of Week")["Sales"].sum()
rating_by_disc = df.groupby("Discount Band")["Rating"].mean()
age = agg("Age Group")
chan_best = chan["m"].idxmax()
chan_big = chan["rev"].idxmax()
sd = ship.loc["Same Day"]
std = ship.loc["Standard"]
books = cat.loc["Books & Stationery"]
bad_prods = prod[(prod["loss"] > .4)].sort_values("loss", ascending=False)
bk = df[df["Category"] == "Books & Stationery"].groupby("Product").agg(prof=("Profit", "sum"), m=("Profit Margin %", "mean"))
bottom_prof = bk.nsmallest(3, "prof")
# simulated impact: cap discounts at 10% for orders above 10% (re-price discount to 10%)
d = d_hi.copy()
list_value = d["Sales"] / (1 - d["Discount"])
new_sales = list_value * 0.90
extra_profit = (new_sales - d["Sales"]).sum()  # ignoring volume loss
# conservative: assume 30% of those orders are lost entirely
lost_orders_profit = d["Profit"].sum() * 0.30
fc_total = fc["Forecast"].sum()
last6 = df[(df["Order Date"] >= "2024-01-01") & (df["Order Date"] < "2024-07-01")]["Sales"].sum()

I = []  # insights
I.append(f"**Business size & health.** {df['Order ID'].nunique():,} orders from {df['Customer ID'].nunique():,} customers produced {M(tot_rev)} revenue and {M(tot_prof)} profit - a thin overall margin of {margin:.1f}%.")
I.append(f"**Revenue is concentrated in one category.** {top_cat} brings {M(elec['rev'])} ({elec['rev']/tot_rev*100:.0f}% of revenue) but only {elec['m']:.1f}% margin and {elec['prof']/tot_prof*100:.0f}% of total profit.")
I.append(f"**Highest-margin categories are small.** {best_m} ({cat.loc[best_m,'m']:.1f}%) and Fashion ({cat.loc['Fashion','m']:.1f}%) earn 6x the margin of Electronics; Fashion alone delivers {cat.loc['Fashion','prof']/tot_prof*100:.0f}% of profit from {cat.loc['Fashion','rev']/tot_rev*100:.0f}% of revenue.")
I.append(f"**{worst_m} barely earns money.** Margin is {books['m']:.1f}% and {books['loss']*100:.0f}% of its order lines lose money.")
I.append(f"**Discounts above 10% destroy profit.** Margin falls from {no_disc['m']:.1f}% (no discount) to {mid_disc['m']:.1f}% (11-20% off) and {hi_disc['m']:.1f}% (>20% off). {hi_disc['loss']*100:.0f}% of orders with >20% discount lose money.")
I.append(f"**Discounts do not buy happier customers.** Average rating is almost identical with no discount ({rating_by_disc['No Discount']:.2f}) and with >20% off ({rating_by_disc['>20%']:.2f}), so deep discounts are not improving satisfaction.")
I.append(f"**Laptops drive revenue but not profit.** Laptops generate {M(lap['rev'])} ({lap['rev']/tot_rev*100:.0f}% of all revenue) at a {lap['m']:.1f}% margin, with {lap['loss']*100:.0f}% of laptop orders loss-making.")
I.append(f"**Loss-making orders are a major leak.** {df['Is Loss'].mean()*100:.1f}% of order lines have negative profit, costing {M(-loss_total)} in total - {(-loss_total)/tot_prof*100:.0f}% of the profit the company kept.")
I.append(f"**Same-day shipping is unprofitable.** Same Day margin is {sd['m']:.1f}% vs {std['m']:.1f}% for Standard, and {sd['loss']*100:.0f}% of Same Day orders lose money, while AOV is no higher ({M(sd['aov'])} vs {M(std['aov'])}).")
I.append(f"**Strong seasonality.** {nd[0]} and {nd[1]} are the two best months; Q4 delivers {q4_share:.0f}% of annual revenue versus an even 25%.")
I.append(f"**2024 revenue fell {abs(rev_g):.1f}% vs 2023** ({M(yr.loc[2023,'rev'])} -> {M(yr.loc[2024,'rev'])}) while the margin stayed flat ({yr.loc[2023,'m']:.1f}% -> {yr.loc[2024,'m']:.1f}%) - the decline is a volume/customer problem, not a pricing problem.")
I.append(f"**Customer revenue is highly concentrated.** The top 20% of customers generate {top20:.0f}% of revenue; the {int(champ['c'])} 'Champions' (RFM) alone produce {champ['share']:.0f}% of revenue.")
I.append(f"**A large group of customers has already gone.** {int(lost['c'])} customers ({lost['c']/seg_t['c'].sum()*100:.0f}%) are in the 'Lost / Churned' RFM segment (long inactive, ~1-2 orders), who together account for just {lost['share']:.1f}% of revenue but represent a shrinking active base.")
I.append(f"**Repeat purchasing is healthy.** {repeat:.0f}% of customers ordered more than once, so retention (not acquisition) is the lever that protects revenue.")
I.append(f"**Regions are similar in margin; North America is the largest.** {reg['rev'].idxmax()} brings {reg['rev'].max()/tot_rev*100:.0f}% of revenue; margins range only from {reg['m'].min():.1f}% ({reg['m'].idxmin()}) to {reg['m'].max():.1f}% ({reg['m'].idxmax()}), so regional differences come from scale, not efficiency.")
I.append(f"**Marketing channels perform similarly.** {chan_big} is the biggest channel ({chan.loc[chan_big,'rev']/tot_rev*100:.0f}% of revenue); {chan_best} has the best margin ({chan.loc[chan_best,'m']:.1f}%). Paid Ads spends are not delivering a better margin ({chan.loc['Paid Ads','m']:.1f}%) than free Organic Search ({chan.loc['Organic Search','m']:.1f}%).")
I.append(f"**Weekends and Fridays sell most.** Saturday is the strongest day ({M(dow.max())}) and Tuesday the weakest ({M(dow.min())}), a {(dow.max()/dow.min()-1)*100:.0f}% gap.")
I.append(f"**Age 25-44 is the core audience.** These two age groups contribute {(age.loc[['25-34','35-44'],'rev'].sum()/tot_rev*100):.0f}% of revenue; the 55+ group is only {age.loc['55+','rev']/tot_rev*100:.0f}%.")
I.append(f"**Several products are structurally unprofitable.** {', '.join(bad_prods.index[:5])} have more than 40% of order lines losing money.")
I.append(f"**Forecast.** Seasonality-adjusted model projects {M(fc_total)} revenue over the next 6 months (Jan-Jun 2025) vs {M(last6)} in the same months of 2024 ({(fc_total/last6-1)*100:+.0f}%). Back-test error on the final 6 months was about 4% (see ML report).")

R = []  # recommendations: (title, finding, action, impact)
R.append(("Cap discounts at 10% and stop >20% promotions",
          f"Orders above 10% discount have {mid_disc['m']:.1f}% / {hi_disc['m']:.1f}% margins and {hi_disc['loss']*100:.0f}% of >20% orders lose money; ratings are unchanged by discounts.",
          "Introduce a hard 10% discount ceiling; require manager approval above that; replace deep discounts with bundles or loyalty points.",
          f"Re-pricing the {len(d_hi):,} orders above 10% discount to 10% would add about {M(extra_profit)} profit before volume effects (a volume drop would offset part of this, so test on one category first)."))
R.append(("Re-price or restructure the Laptop line",
          f"Laptops are {lap['rev']/tot_rev*100:.0f}% of revenue at a {lap['m']:.1f}% margin and {lap['loss']*100:.0f}% of orders lose money.",
          "Raise laptop list prices 3-5%, remove laptops from discount campaigns, bundle with high-margin accessories (headphones, smartwatch).",
          "Every 1 point of laptop margin is worth about " + M(lap['rev'] * 0.01) + "."))
R.append(("Shift marketing & stock toward Fashion and Beauty",
          f"Fashion ({cat.loc['Fashion','m']:.1f}%) and Beauty ({cat.loc['Beauty','m']:.1f}%) have the best margins and almost no losses.",
          "Move 15-20% of paid-ads budget from Electronics to Fashion/Beauty; feature Jackets, Handbags and Perfume in homepage and email campaigns.",
          f"If Fashion/Beauty revenue grows 20%, profit rises by about {M((cat.loc['Fashion','prof']+cat.loc['Beauty','prof'])*0.2)}."))
R.append(("Fix or exit Books & Stationery low-value lines",
          f"Margin is only {books['m']:.1f}% with {books['loss']*100:.0f}% loss-making lines; {', '.join(bottom_prof.index[:3])} are the weakest products.",
          "Set a minimum order value / free-shipping threshold, remove discounts on this category, cross-sell to larger baskets, and delist the permanently loss-making SKUs.",
          f"Removes up to {M(-df[(df['Category']=='Books & Stationery')&(df['Profit']<0)]['Profit'].sum())} of losses made on loss-making Books & Stationery orders over the two years."))
R.append(("Charge for Same-Day delivery",
          f"Same-Day margin is {sd['m']:.1f}% vs {std['m']:.1f}% Standard and {sd['loss']*100:.0f}% of its orders lose money.",
          "Add a $10-15 same-day fee or limit it to orders above $150; promote Standard shipping with a delivery-date guarantee.",
          f"Protects roughly {M(sd['n'] * sd['loss'] * 10)} (about $10 per loss-making same-day order)."))
R.append(("Launch a win-back campaign for lapsed customers",
          f"{int(lost['c'])} customers are in the Lost segment and 2024 revenue dropped {abs(rev_g):.0f}%.",
          "Send a 3-step email/SMS sequence (reminder, no-discount personalised recommendations, 10% max coupon) to customers inactive over 180 days; track reactivation rate.",
          f"Reactivating just 10% of lost customers at the average Loyal-segment spend adds about {M(lost['c']*0.10*seg.loc[seg['Segment']=='Loyal','Monetary'].mean()/2)} (assuming half of their historic spend)."))
R.append(("Protect the Champions with a VIP programme",
          f"{int(champ['c'])} Champions produce {champ['share']:.0f}% of revenue; the top 20% of customers give {top20:.0f}%.",
          "Create tiered loyalty rewards, early access to new products, and a dedicated support line; review these accounts monthly.",
          f"Losing even 10% of Champions would cost about {M(champ['rev']*0.10)}."))
R.append(("Use the churn model to trigger retention offers",
          f"The Random Forest churn model flags customers likely to stop buying; {len(risk)} high-value customers currently exceed 60% churn probability (file: high_value_at_risk_customers.csv).",
          "Give the list to CRM weekly; contact the highest-value at-risk customers with personal outreach and a non-discount incentive (free shipping, early access).",
          f"These {len(risk)} customers represent {M(risk['monetary'].sum())} of past revenue."))
R.append(("Build a Q4 inventory and campaign plan",
          f"{nd[0]} and {nd[1]} are peak months and Q4 delivers {q4_share:.0f}% of revenue.",
          "Pre-order stock for top sellers by September, run margin-aware Black Friday offers (bundles, not price cuts), and add support staff in Nov-Dec.",
          "Avoids stock-outs in the 3 highest-revenue months and protects margin during peak discount pressure."))
R.append(("Rebalance marketing spend toward efficient channels",
          f"Paid Ads margin ({chan.loc['Paid Ads','m']:.1f}%) is no better than Organic Search ({chan.loc['Organic Search','m']:.1f}%); Email and Referral have the best margins ({chan.loc['Email','m']:.1f}% / {chan.loc['Referral','m']:.1f}%).",
          "Invest in SEO, email automation and a referral reward scheme; cap paid-ads CPA and track profit-per-channel instead of revenue.",
          "Lower acquisition cost for the same revenue."))
R.append(("Run targeted promotions on weak days",
          f"Tuesday revenue is {(dow.max()/dow.min()-1)*100:.0f}% lower than Saturday.",
          "Use flash sales (bundle-based, not price cuts) and email send-times on Tuesday-Thursday to smooth demand.",
          f"Lifting the three weakest days to the average would add roughly {M((dow.mean()*3 - dow.nsmallest(3).sum())/2)} of extra revenue per year (about {M((dow.mean()*3 - dow.nsmallest(3).sum())/2*margin/100)} profit at the current margin)."))
R.append(("Grow in under-penetrated regions through targeted offers",
          f"Australia and South America together give only {(reg.loc[['Australia','South America'],'rev'].sum()/tot_rev*100):.0f}% of revenue and show below-average margins ({reg.loc['Australia','m']:.1f}% and {reg.loc['South America','m']:.1f}% vs {margin:.1f}% overall).",
          "Test local-currency pricing, regional free-shipping thresholds and local payment methods before spending on large acquisition campaigns.",
          "Small pilot first; scale only if margin exceeds the company average."))

out = ["# Insights & Business Recommendations", "",
       f"*Generated automatically from the cleaned dataset ({len(df):,} orders, {df['Order Date'].min().date()} to {df['Order Date'].max().date()}).*", "",
       f"## Part A - {len(I)} Key Insights", ""]
out += [f"{i+1}. {t}" for i, t in enumerate(I)]
out += ["", f"## Part B - {len(R)} Actionable Recommendations", ""]
for i, (t, f, a, imp) in enumerate(R, 1):
    out += [f"### {i}. {t}", f"- **Finding:** {f}", f"- **Action:** {a}", f"- **Expected impact:** {imp}", ""]
out += ["## Part C - Machine learning results", "", "```", (BASE / "outputs" / "ml_report.txt").read_text(encoding="utf-8"), "```"]

(BASE / "outputs").mkdir(exist_ok=True)
(BASE / "outputs" / "insights_and_recommendations.md").write_text("\n".join(out), encoding="utf-8")
print(f"{len(I)} insights and {len(R)} recommendations written to outputs/insights_and_recommendations.md")
