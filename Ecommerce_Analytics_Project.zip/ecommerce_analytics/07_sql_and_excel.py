"""
STEP 7 - SQL + EXCEL deliverables
 - Loads the clean data into a SQLite database and runs every query in sql/analysis_queries.sql
 - Exports an Excel workbook (outputs/Business_Analytics_Report.xlsx) with KPI, category, product, region,
   monthly, segment and forecast sheets, formatted and ready for pivot tables.
"""
import re, sqlite3
from pathlib import Path
import pandas as pd

BASE = Path(__file__).parent
df = pd.read_csv(BASE / "data" / "clean_orders.csv")
db = BASE / "data" / "ecommerce.db"
con = sqlite3.connect(db)
df.to_sql("orders", con, if_exists="replace", index=False)

# ---- run SQL file
sql = (BASE / "sql" / "analysis_queries.sql").read_text(encoding="utf-8")
queries = [q.strip() for q in re.split(r";\s*\n", sql) if "SELECT" in q.upper()]
results = []
for q in queries:
    title = re.search(r"--\s*(Q\d+\..*)", q)
    out = pd.read_sql_query(re.sub(r"(?m)^--.*$", "", q), con)
    results.append((title.group(1) if title else "Query", out))
    print("\n" + (title.group(1) if title else "Query"))
    print(out.head(6).to_string(index=False))
con.close()

# ---- Excel workbook
O = BASE / "outputs"
xl = O / "Business_Analytics_Report.xlsx"
with pd.ExcelWriter(xl, engine="openpyxl") as w:
    pd.read_csv(O / "kpi_summary.csv").rename(columns={"Unnamed: 0": "KPI"}).to_excel(w, sheet_name="KPIs", index=False)
    pd.read_csv(O / "kpi_yearly.csv").to_excel(w, sheet_name="Yearly", index=False)
    pd.read_csv(O / "kpi_monthly.csv").to_excel(w, sheet_name="Monthly", index=False)
    pd.read_csv(O / "category_performance.csv").to_excel(w, sheet_name="Category", index=False)
    pd.read_csv(O / "product_performance.csv").to_excel(w, sheet_name="Product", index=False)
    pd.read_csv(O / "region_performance.csv").to_excel(w, sheet_name="Region", index=False)
    pd.read_csv(O / "segment_summary.csv").to_excel(w, sheet_name="RFM Segments", index=False)
    pd.read_csv(O / "sales_forecast_next_6_months.csv").to_excel(w, sheet_name="Forecast", index=False)
    pd.read_csv(O / "product_demand_forecast.csv").to_excel(w, sheet_name="Product Demand", index=False)
    pd.read_csv(O / "high_value_at_risk_customers.csv").to_excel(w, sheet_name="At-Risk Customers", index=False)
    df.to_excel(w, sheet_name="Clean Data", index=False)
    from openpyxl.styles import Font, PatternFill
    from openpyxl.utils import get_column_letter
    for ws in w.book.worksheets:
        for c in ws[1]:
            c.font = Font(bold=True, color="FFFFFF")
            c.fill = PatternFill("solid", fgColor="2563EB")
        ws.freeze_panes = "A2"
        for i, col in enumerate(ws.columns, 1):
            width = max(len(str(c.value)) if c.value is not None else 0 for c in list(col)[:200]) + 2
            ws.column_dimensions[get_column_letter(i)].width = min(max(width, 10), 40)
print(f"\nSQLite DB: {db}\nExcel report: {xl}")
