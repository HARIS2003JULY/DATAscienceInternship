# Building the dashboard in Power BI or Tableau (optional)

The project already ships a working dashboard (`dashboard.html`). If your instructor requires
**Power BI** or **Tableau**, build the same six pages from `data/clean_orders.csv`.

## Power BI Desktop (free, Windows)
1. **Get data -> Text/CSV -> `data/clean_orders.csv` -> Transform Data.** Check types: *Order Date / Ship Date* = Date,
   *Sales / Profit / Unit Price* = Fixed decimal, *Discount* = Percentage, *Year* = Whole number (not summarised). Close & Apply.
2. **Date table:** Modeling -> New table  
   `Calendar = ADDCOLUMNS(CALENDAR(DATE(2023,1,1),DATE(2024,12,31)),"Year",YEAR([Date]),"MonthNo",MONTH([Date]),"Month",FORMAT([Date],"MMM"))`  
   Relate `Calendar[Date]` -> `clean_orders[Order Date]`.
3. **DAX measures** (Modeling -> New measure):
```
Total Revenue   = SUM(clean_orders[Sales])
Total Profit    = SUM(clean_orders[Profit])
Total Orders    = DISTINCTCOUNT(clean_orders[Order ID])
Avg Order Value = DIVIDE([Total Revenue],[Total Orders])
Profit Margin % = DIVIDE([Total Profit],[Total Revenue])
Customer Count  = DISTINCTCOUNT(clean_orders[Customer ID])
Revenue LY      = CALCULATE([Total Revenue], SAMEPERIODLASTYEAR('Calendar'[Date]))
Growth %        = DIVIDE([Total Revenue]-[Revenue LY],[Revenue LY])
Loss Order %    = DIVIDE(SUM(clean_orders[Is Loss]),COUNTROWS(clean_orders))
Repeat Cust %   = DIVIDE(COUNTROWS(FILTER(VALUES(clean_orders[Customer ID]),CALCULATE(DISTINCTCOUNT(clean_orders[Order ID]))>1)),[Customer Count])
```
4. **Pages (add 6 pages, same names as the HTML dashboard):**
   - *Executive Summary:* 6 KPI cards, line chart (Calendar[Month] vs Revenue & Profit), donut by Category, clustered bar by Region.
   - *Sales:* column chart orders by YearMonth, quarter, day of week, bar by Marketing Channel, Shipping Mode, Payment Method.
   - *Product:* top 10 / bottom 10 products by profit (Filters pane -> Top N), margin by category, scatter (Revenue, Margin%, size = Quantity).
   - *Customer:* donut by Segment, AOV by Age Group, histogram of orders per customer, top-10 table, import `outputs/customer_segments_rfm.csv` for RFM segments.
   - *Regional:* filled map (Region/City), matrix Region x Category (conditional formatting).
   - *Profit:* margin by Discount Band, loss % by category, waterfall.
5. **Slicers (Insert -> Slicer):** Year, Region, Category, Segment. Use **View -> Sync slicers** so they apply to every page.
6. File -> Save as `.pbix`; File -> Export -> PDF for submission.

## Tableau Public (free)
1. Connect -> Text file -> `clean_orders.csv`. Set *Order Date* to Date.
2. Calculated fields: `Margin % = SUM([Profit])/SUM([Sales])`, `AOV = SUM([Sales])/COUNTD([Order ID])`.
3. One worksheet per chart (same list as above), then Dashboard -> drag sheets; add filters (Year, Region, Category, Segment) and
   *Apply to worksheets -> All using this data source*.
