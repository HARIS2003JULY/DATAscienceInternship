# E-Commerce Business Analytics - Complete Project (Task 04, Devixo Solutions)

A raw, messy e-commerce dataset is turned into a complete decision-making solution:
**cleaning -> EDA -> KPIs -> interactive dashboard -> insights & recommendations -> machine learning.**

Chosen project: **E-Commerce Business Analytics** · Technologies used: Python, Pandas, NumPy, SQL (SQLite), Excel, Plotly dashboard (+ Power BI/Tableau guide), scikit-learn.

---

## 1. How to run it (step by step)

### Requirements
* Python 3.9 or newer (check with `python --version`)
* Internet only for the first `pip install`

### Steps
```bash
# 1. open a terminal in the project folder
cd ecommerce_analytics

# 2. (recommended) create a virtual environment
python -m venv venv
venv\Scripts\activate          # Windows
source venv/bin/activate       # Mac / Linux

# 3. install libraries
pip install -r requirements.txt

# 4. run EVERYTHING with one command (takes ~1-2 minutes)
python run_all.py
```
Then:
1. Double-click **`dashboard.html`** - the interactive dashboard opens in your browser (works offline).
2. Open **`outputs/insights_and_recommendations.md`** - 20 insights, 12 recommendations, ML results.
3. Open **`outputs/Business_Analytics_Report.xlsx`** - Excel workbook.
4. Look in the **`charts/`** folder - 21 EDA charts + 4 ML charts (25 total).

You can also run the scripts one at a time (`python 02_data_cleaning.py`, etc.) in numeric order.

### Using YOUR OWN dataset (e.g. Kaggle "Superstore", "Online Retail")
1. Put the file at `data/raw_ecommerce_orders.csv` and skip `01_generate_raw_data.py`.
2. Rename your columns to match the names used in `02_data_cleaning.py` (Order ID, Order Date, Customer ID, Region, Category, Product, Sales, Quantity, Discount, Profit ...), or edit the names inside the scripts.
3. Run `02` -> `07` in order.

---

## 2. Project structure

| File / folder | Task requirement it covers |
|---|---|
| `01_generate_raw_data.py` | Creates the raw dataset (12,220 rows, deliberately messy: missing values, duplicates, outliers, wrong types, mixed date formats) |
| `02_data_cleaning.py` | **Part 1** - import, missing values, duplicates, outliers, data types, feature engineering |
| `03_eda_kpis.py` | **Part 2** EDA (21 visualisations) and **Part 3** KPIs |
| `04_ml_models.py` | **Bonus** - RFM segmentation, churn prediction, sales forecast, product demand |
| `05_build_dashboard.py` -> `dashboard.html` | **Part 4** - 6-page interactive dashboard with 4 slicers |
| `06_insights_report.py` | **Part 5** - 20 insights + 12 recommendations, each tied to a computed finding |
| `07_sql_and_excel.py`, `sql/analysis_queries.sql` | SQL (15 queries) and Excel deliverable |
| `POWERBI_TABLEAU_GUIDE.md` | DAX measures + page-by-page build guide if Power BI / Tableau is required |
| `data/` | `raw_ecommerce_orders.csv`, `clean_orders.csv`, `ecommerce.db` |
| `outputs/` | cleaning report, KPI tables, ML report, forecasts, at-risk customers, Excel, recommendations |

---

## 3. What each part does

### Part 1 - Data preparation (`02_data_cleaning.py`)
* **Duplicates:** 220 exact duplicate rows removed.
* **Data types:** dates parsed from 4 different formats; `$` and `%` symbols stripped from numeric columns.
* **Missing values:** customer attributes filled from the same customer's other orders, else median/mode; Rating -> product median (with a flag column); Profit rebuilt from the category's average margin.
* **Outliers:** price > 3x the product median, quantity outside 1-10 and ages outside 18-80 are corrected; high-value orders (IQR outliers) are kept because laptops genuinely cost more.
* **Feature engineering:** Year, Month, Quarter, YearMonth, Day of Week, Shipping Days, Profit Margin %, Is Loss, Age Group, Discount Band, Order Value Band.
* Full log: `outputs/cleaning_report.txt`.

### Part 2 - EDA (21 charts in `charts/`)
Trends (monthly, MoM, quarterly, day-of-week) · top & bottom categories/products · product matrix · discount vs margin · correlation heat-map · seasonality heat-map · region · customer segment, age, channel, payment, purchase frequency, Pareto, shipping, box-plot.

### Part 3 - KPIs (`outputs/kpi_summary.csv`)
Total Revenue **$2,758,380** · Total Profit **$307,043** · Orders **12,000** · AOV **$229.87** · Profit Margin **11.13%** · Customers **2,205** · Revenue growth 2024 vs 2023 **-19.5%** · Repeat-customer rate 79.6% · Loss-making orders 15.6% (plus more in the file).

### Part 4 - Dashboard (`dashboard.html`)
Pages: Executive Summary · Sales · Product · Customer · Regional · Profit (≈ 30 interactive charts).
**Slicers:** Year, Region, Category, Customer Segment - every KPI and chart updates instantly. Hover, zoom and download any chart.

### Part 5 - Insights & recommendations
See `outputs/insights_and_recommendations.md`. Headline findings:
* **Electronics = 62% of revenue but only 5% margin**; Laptops: 31% of revenue, 2.6% margin, 41% of orders lose money.
* **Discounts above 10% destroy profit** (margin 17.4% -> 0.7% -> -16.4%), and they do not improve ratings.
* **Fashion + Beauty** earn ~29% margin with almost no losses.
* **Same-day shipping** loses money (7.4% margin, 34% loss-making orders).
* **2024 revenue fell 19.5%** while margin stayed flat - a customer/volume (churn) problem; top 20% of customers generate 66% of revenue.

### Bonus - Machine learning (`04_ml_models.py`)
| Model | Result |
|---|---|
| Customer segmentation (RFM + K-Means, 4 clusters) | Champions 275 customers = 49% of revenue; Lost 784 customers = 5.5% |
| Churn prediction (Random Forest, time-split, no leakage) | AUC 0.71, accuracy 0.64; recency, tenure and spend are the main drivers |
| Sales forecast (seasonal-level model) | Back-test MAPE about 4% on the last 6 months; Jan-Jun 2025 forecast $571k |
| Product demand (next quarter units) | `outputs/product_demand_forecast.csv` |

---

## 4. Honest notes / limitations (mention these in your viva)
* The dataset is **synthetic** (generated by `01_generate_raw_data.py`) so the project runs anywhere; the pipeline works unchanged on a real dataset once the column names match.
* The churn model is moderate (AUC 0.71) - customer behaviour here is largely random, so do not oversell it. A real dataset with more behavioural features would score higher.
* The sales forecast's seasonal index is computed on all 24 months, so the back-test is slightly optimistic. With only 2 years of history the forecast is indicative, not exact.
* Recommendation "expected impact" figures are simple estimates that ignore volume loss from price changes; they should be validated with an A/B test.

---

## 5. Suggested submission / presentation order
1. Business problem and dataset (README section 1-2) -> 2. Cleaning report -> 3. KPI cards -> 4. EDA charts -> 5. Live dashboard demo (use slicers: Region = Asia, Category = Electronics) -> 6. Insights -> 7. Recommendations -> 8. ML bonus -> 9. Limitations.
