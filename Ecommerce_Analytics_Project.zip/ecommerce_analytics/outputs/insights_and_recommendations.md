# Insights & Business Recommendations

*Generated automatically from the cleaned dataset (12,000 orders, 2023-01-01 to 2024-12-31).*

## Part A - 20 Key Insights

1. **Business size & health.** 12,000 orders from 2,205 customers produced $2,758,380 revenue and $307,043 profit - a thin overall margin of 11.1%.
2. **Revenue is concentrated in one category.** Electronics brings $1,702,099 (62% of revenue) but only 5.0% margin and 28% of total profit.
3. **Highest-margin categories are small.** Beauty (29.2%) and Fashion (29.0%) earn 6x the margin of Electronics; Fashion alone delivers 32% of profit from 12% of revenue.
4. **Books & Stationery barely earns money.** Margin is 2.1% and 46% of its order lines lose money.
5. **Discounts above 10% destroy profit.** Margin falls from 17.4% (no discount) to 0.7% (11-20% off) and -16.4% (>20% off). 74% of orders with >20% discount lose money.
6. **Discounts do not buy happier customers.** Average rating is almost identical with no discount (3.96) and with >20% off (3.94), so deep discounts are not improving satisfaction.
7. **Laptops drive revenue but not profit.** Laptops generate $857,892 (31% of all revenue) at a 2.6% margin, with 41% of laptop orders loss-making.
8. **Loss-making orders are a major leak.** 15.6% of order lines have negative profit, costing $43,614 in total - 14% of the profit the company kept.
9. **Same-day shipping is unprofitable.** Same Day margin is 7.4% vs 12.0% for Standard, and 34% of Same Day orders lose money, while AOV is no higher ($232 vs $229).
10. **Strong seasonality.** Dec and Nov are the two best months; Q4 delivers 30% of annual revenue versus an even 25%.
11. **2024 revenue fell 19.5% vs 2023** ($1,528,344 -> $1,230,036) while the margin stayed flat (11.1% -> 11.2%) - the decline is a volume/customer problem, not a pricing problem.
12. **Customer revenue is highly concentrated.** The top 20% of customers generate 66% of revenue; the 275 'Champions' (RFM) alone produce 49% of revenue.
13. **A large group of customers has already gone.** 784 customers (36%) are in the 'Lost / Churned' RFM segment (long inactive, ~1-2 orders), who together account for just 5.5% of revenue but represent a shrinking active base.
14. **Repeat purchasing is healthy.** 80% of customers ordered more than once, so retention (not acquisition) is the lever that protects revenue.
15. **Regions are similar in margin; North America is the largest.** North America brings 34% of revenue; margins range only from 9.9% (South America) to 11.9% (Europe), so regional differences come from scale, not efficiency.
16. **Marketing channels perform similarly.** Organic Search is the biggest channel (29% of revenue); Referral has the best margin (11.9%). Paid Ads spends are not delivering a better margin (10.6%) than free Organic Search (11.0%).
17. **Weekends and Fridays sell most.** Saturday is the strongest day ($452,179) and Tuesday the weakest ($355,086), a 27% gap.
18. **Age 25-44 is the core audience.** These two age groups contribute 62% of revenue; the 55+ group is only 5%.
19. **Several products are structurally unprofitable.** Notebook Pack, Novel, Textbook, Pen Set, Laptop have more than 40% of order lines losing money.
20. **Forecast.** Seasonality-adjusted model projects $571,018 revenue over the next 6 months (Jan-Jun 2025) vs $540,203 in the same months of 2024 (+6%). Back-test error on the final 6 months was about 4% (see ML report).

## Part B - 12 Actionable Recommendations

### 1. Cap discounts at 10% and stop >20% promotions
- **Finding:** Orders above 10% discount have 0.7% / -16.4% margins and 74% of >20% orders lose money; ratings are unchanged by discounts.
- **Action:** Introduce a hard 10% discount ceiling; require manager approval above that; replace deep discounts with bundles or loyalty points.
- **Expected impact:** Re-pricing the 2,973 orders above 10% discount to 10% would add about $69,949 profit before volume effects (a volume drop would offset part of this, so test on one category first).

### 2. Re-price or restructure the Laptop line
- **Finding:** Laptops are 31% of revenue at a 2.6% margin and 41% of orders lose money.
- **Action:** Raise laptop list prices 3-5%, remove laptops from discount campaigns, bundle with high-margin accessories (headphones, smartwatch).
- **Expected impact:** Every 1 point of laptop margin is worth about $8,579.

### 3. Shift marketing & stock toward Fashion and Beauty
- **Finding:** Fashion (29.0%) and Beauty (29.2%) have the best margins and almost no losses.
- **Action:** Move 15-20% of paid-ads budget from Electronics to Fashion/Beauty; feature Jackets, Handbags and Perfume in homepage and email campaigns.
- **Expected impact:** If Fashion/Beauty revenue grows 20%, profit rises by about $26,666.

### 4. Fix or exit Books & Stationery low-value lines
- **Finding:** Margin is only 2.1% with 46% loss-making lines; Notebook Pack, Pen Set, Textbook are the weakest products.
- **Action:** Set a minimum order value / free-shipping threshold, remove discounts on this category, cross-sell to larger baskets, and delist the permanently loss-making SKUs.
- **Expected impact:** Removes up to $3,215 of losses made on loss-making Books & Stationery orders over the two years.

### 5. Charge for Same-Day delivery
- **Finding:** Same-Day margin is 7.4% vs 12.0% Standard and 34% of its orders lose money.
- **Action:** Add a $10-15 same-day fee or limit it to orders above $150; promote Standard shipping with a delivery-date guarantee.
- **Expected impact:** Protects roughly $3,120 (about $10 per loss-making same-day order).

### 6. Launch a win-back campaign for lapsed customers
- **Finding:** 784 customers are in the Lost segment and 2024 revenue dropped 20%.
- **Action:** Send a 3-step email/SMS sequence (reminder, no-discount personalised recommendations, 10% max coupon) to customers inactive over 180 days; track reactivation rate.
- **Expected impact:** Reactivating just 10% of lost customers at the average Loyal-segment spend adds about $51,161 (assuming half of their historic spend).

### 7. Protect the Champions with a VIP programme
- **Finding:** 275 Champions produce 49% of revenue; the top 20% of customers give 66%.
- **Action:** Create tiered loyalty rewards, early access to new products, and a dedicated support line; review these accounts monthly.
- **Expected impact:** Losing even 10% of Champions would cost about $134,391.

### 8. Use the churn model to trigger retention offers
- **Finding:** The Random Forest churn model flags customers likely to stop buying; 100 high-value customers currently exceed 60% churn probability (file: high_value_at_risk_customers.csv).
- **Action:** Give the list to CRM weekly; contact the highest-value at-risk customers with personal outreach and a non-discount incentive (free shipping, early access).
- **Expected impact:** These 100 customers represent $352,814 of past revenue.

### 9. Build a Q4 inventory and campaign plan
- **Finding:** Dec and Nov are peak months and Q4 delivers 30% of revenue.
- **Action:** Pre-order stock for top sellers by September, run margin-aware Black Friday offers (bundles, not price cuts), and add support staff in Nov-Dec.
- **Expected impact:** Avoids stock-outs in the 3 highest-revenue months and protects margin during peak discount pressure.

### 10. Rebalance marketing spend toward efficient channels
- **Finding:** Paid Ads margin (10.6%) is no better than Organic Search (11.0%); Email and Referral have the best margins (11.8% / 11.9%).
- **Action:** Invest in SEO, email automation and a referral reward scheme; cap paid-ads CPA and track profit-per-channel instead of revenue.
- **Expected impact:** Lower acquisition cost for the same revenue.

### 11. Run targeted promotions on weak days
- **Finding:** Tuesday revenue is 27% lower than Saturday.
- **Action:** Use flash sales (bundle-based, not price cuts) and email send-times on Tuesday-Thursday to smooth demand.
- **Expected impact:** Lifting the three weakest days to the average would add roughly $36,726 of extra revenue per year (about $4,088 profit at the current margin).

### 12. Grow in under-penetrated regions through targeted offers
- **Finding:** Australia and South America together give only 15% of revenue and show below-average margins (10.6% and 9.9% vs 11.1% overall).
- **Action:** Test local-currency pricing, regional free-shipping thresholds and local payment methods before spending on large acquisition campaigns.
- **Expected impact:** Small pilot first; scale only if margin exceeds the company average.

## Part C - Machine learning results

```
=== (a) CUSTOMER SEGMENTATION (RFM + K-Means, k=4) ===
                      Customers  Avg_Recency_Days  Avg_Orders  Avg_Spend  Total_Revenue  Revenue Share %
Segment                                                                                                 
Champions                   275              51.7        20.0     4886.9      1343910.4             48.7
Loyal                       671             307.4         4.8     1305.1       875738.4             31.7
At Risk / Occasional        475              35.6         4.2      814.0       386628.8             14.0
Lost / Churned              784             350.0         1.6      194.0       152102.5              5.5

=== (b) CHURN PREDICTION (churn = no purchase in the 6 months after 30-Jun-2024) ===
Customers modelled: 2,049 | churn rate: 51.7%
Logistic Regression  AUC=0.680
Random Forest        AUC=0.713  Accuracy=0.635
              precision    recall  f1-score   support

    Retained       0.64      0.55      0.59       248
     Churned       0.63      0.72      0.67       265

    accuracy                           0.64       513
   macro avg       0.64      0.63      0.63       513
weighted avg       0.64      0.64      0.63       513

Top feature drivers: recency, tenure, monetary
(c) Seasonal-level model back-test (last 6 months): MAE=$4,408, MAPE=4.3%
    Naive average baseline:                          MAE=$17,419, MAPE=14.3%

=== (c) SALES FORECAST: next 6 months ===
YearMonth  Forecast
  2025-01   95421.0
  2025-02   89242.0
  2025-03  100048.0
  2025-04   85986.0
  2025-05  100595.0
  2025-06   99726.0

=== (d) PRODUCT DEMAND FORECAST (top 8 by next-quarter units) ===
        Product  Units_Last_Quarter  Forecast_Units_Next_Quarter  Change %
        Blender                 247                          184     -25.5
         Jacket                 266                          158     -40.6
         Tablet                 171                          144     -15.8
     Hair Dryer                 199                          127     -36.2
Fitness Tracker                 226                          126     -44.2
          Novel                 175                          125     -28.6
         Laptop                 172                          119     -30.8
    Moisturizer                 163                          115     -29.4
```