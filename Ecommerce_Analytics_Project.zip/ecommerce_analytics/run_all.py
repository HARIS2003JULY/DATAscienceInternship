"""Run the whole project end-to-end:  python run_all.py"""
import subprocess, sys, time
from pathlib import Path

STEPS = [
    ("01_generate_raw_data.py", "Generate raw (messy) dataset   [skip if you use your own CSV]"),
    ("02_data_cleaning.py",     "Part 1 - Data cleaning & feature engineering"),
    ("03_eda_kpis.py",          "Part 2/3 - EDA charts (21) & KPIs"),
    ("04_ml_models.py",         "Bonus - Segmentation, churn, forecasting, demand"),
    ("05_build_dashboard.py",   "Part 4 - Interactive dashboard (dashboard.html)"),
    ("06_insights_report.py",   "Part 5 - 20 insights & 12 recommendations"),
    ("07_sql_and_excel.py",     "SQL queries + Excel report"),
]
base = Path(__file__).parent
for script, label in STEPS:
    print(f"\n{'='*70}\n>> {label}\n{'='*70}")
    t = time.time()
    r = subprocess.run([sys.executable, str(base / script)], cwd=base)
    if r.returncode:
        sys.exit(f"FAILED at {script}")
    print(f"[done in {time.time()-t:.1f}s]")
print("\nALL DONE. Open dashboard.html in your browser, and read outputs/insights_and_recommendations.md")
