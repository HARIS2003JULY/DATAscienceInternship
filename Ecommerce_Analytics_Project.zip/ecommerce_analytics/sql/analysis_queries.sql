-- ============================================================
-- SQL ANALYSIS QUERIES  (table name: orders)
-- Works in SQLite / PostgreSQL / MySQL (minor date-function changes).
-- Run automatically by 07_sql_and_excel.py, or load data/clean_orders.csv
-- into any database (e.g. DB Browser for SQLite, MySQL Workbench) and run by hand.
-- ============================================================

-- Q1. Core KPIs
SELECT ROUND(SUM(Sales),2) AS total_revenue, ROUND(SUM(Profit),2) AS total_profit,
       COUNT(DISTINCT "Order ID") AS total_orders, ROUND(SUM(Sales)/COUNT(DISTINCT "Order ID"),2) AS avg_order_value,
       ROUND(100.0*SUM(Profit)/SUM(Sales),2) AS profit_margin_pct, COUNT(DISTINCT "Customer ID") AS customers
FROM orders;

-- Q2. Revenue, profit and margin by category
SELECT Category, ROUND(SUM(Sales),0) AS revenue, ROUND(SUM(Profit),0) AS profit,
       ROUND(100.0*SUM(Profit)/SUM(Sales),2) AS margin_pct
FROM orders GROUP BY Category ORDER BY revenue DESC;

-- Q3. Year-over-year growth
SELECT Year, ROUND(SUM(Sales),0) AS revenue,
       ROUND(100.0*(SUM(Sales) - LAG(SUM(Sales)) OVER (ORDER BY Year)) / LAG(SUM(Sales)) OVER (ORDER BY Year),1) AS growth_pct
FROM orders GROUP BY Year;

-- Q4. Month-over-month trend
SELECT YearMonth, ROUND(SUM(Sales),0) AS revenue, ROUND(SUM(Profit),0) AS profit
FROM orders GROUP BY YearMonth ORDER BY YearMonth;

-- Q5. Top 10 products by profit
SELECT Product, Category, ROUND(SUM(Sales),0) AS revenue, ROUND(SUM(Profit),0) AS profit
FROM orders GROUP BY Product, Category ORDER BY profit DESC LIMIT 10;

-- Q6. Bottom 10 products by profit
SELECT Product, Category, ROUND(SUM(Sales),0) AS revenue, ROUND(SUM(Profit),0) AS profit,
       ROUND(100.0*SUM("Is Loss")/COUNT(*),1) AS pct_loss_lines
FROM orders GROUP BY Product, Category ORDER BY profit ASC LIMIT 10;

-- Q7. Discount impact on profitability
SELECT "Discount Band", COUNT(*) AS order_lines, ROUND(SUM(Sales),0) AS revenue, ROUND(SUM(Profit),0) AS profit,
       ROUND(100.0*SUM(Profit)/SUM(Sales),2) AS margin_pct, ROUND(100.0*SUM("Is Loss")/COUNT(*),1) AS pct_loss_lines
FROM orders GROUP BY "Discount Band" ORDER BY margin_pct DESC;

-- Q8. Regional performance
SELECT Region, ROUND(SUM(Sales),0) AS revenue, ROUND(SUM(Profit),0) AS profit, COUNT(DISTINCT "Customer ID") AS customers
FROM orders GROUP BY Region ORDER BY revenue DESC;

-- Q9. Top 10 customers (lifetime value)
SELECT "Customer ID", COUNT(DISTINCT "Order ID") AS orders, ROUND(SUM(Sales),0) AS revenue, ROUND(SUM(Profit),0) AS profit
FROM orders GROUP BY "Customer ID" ORDER BY revenue DESC LIMIT 10;

-- Q10. Repeat vs one-time customers
SELECT CASE WHEN n > 1 THEN 'Repeat' ELSE 'One-time' END AS customer_type, COUNT(*) AS customers
FROM (SELECT "Customer ID", COUNT(DISTINCT "Order ID") AS n FROM orders GROUP BY "Customer ID") GROUP BY 1;

-- Q11. Customers inactive for 180+ days (churn risk), as of last order date in data
SELECT COUNT(*) AS inactive_customers FROM (
  SELECT "Customer ID", MAX("Order Date") AS last_order FROM orders GROUP BY "Customer ID")
WHERE julianday((SELECT MAX("Order Date") FROM orders)) - julianday(last_order) > 180;

-- Q12. Shipping mode profitability
SELECT "Shipping Mode", COUNT(*) AS order_lines, ROUND(AVG(Profit),2) AS avg_profit_per_line,
       ROUND(100.0*SUM(Profit)/SUM(Sales),2) AS margin_pct
FROM orders GROUP BY "Shipping Mode" ORDER BY margin_pct;

-- Q13. Marketing channel performance
SELECT "Marketing Channel", ROUND(SUM(Sales),0) AS revenue, ROUND(100.0*SUM(Profit)/SUM(Sales),2) AS margin_pct
FROM orders GROUP BY "Marketing Channel" ORDER BY revenue DESC;

-- Q14. Running (cumulative) revenue by month
SELECT YearMonth, ROUND(SUM(Sales),0) AS revenue,
       ROUND(SUM(SUM(Sales)) OVER (ORDER BY YearMonth),0) AS cumulative_revenue
FROM orders GROUP BY YearMonth;

-- Q15. Best category in each region (window function)
SELECT Region, Category, revenue FROM (
  SELECT Region, Category, ROUND(SUM(Sales),0) AS revenue,
         RANK() OVER (PARTITION BY Region ORDER BY SUM(Sales) DESC) AS rk
  FROM orders GROUP BY Region, Category) WHERE rk = 1;
